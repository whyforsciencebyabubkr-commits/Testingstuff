-- Demo seed for local development only.
-- Passwords: MainAdmin123!, RestrictedAdmin123!, TeacherA123!, TeacherB123!, TeacherC123!, Student123!

create temporary table _seed_users (username text, role public.app_role, full_name text, password text, admin_access public.admin_access);
insert into _seed_users values
('mainadmin','admin','الإداري الرئيسي','MainAdmin123!','full'),
('adminrestricted','admin','إداري مقيد','RestrictedAdmin123!','restricted'),
('teacher_a','teacher','المعلم أحمد','TeacherA123!',null),
('teacher_b','teacher','المعلمة سارة','TeacherB123!',null),
('teacher_c','teacher','المعلم محمد','TeacherC123!',null),
('student01','student','علي أحمد','Student123!',null),
('student02','student','سارة علي','Student123!',null),
('student03','student','محمد كريم','Student123!',null),
('student04','student','نور حسين','Student123!',null),
('student05','student','زينب عمر','Student123!',null),
('student06','student','حسن قاسم','Student123!',null),
('student07','student','مريم سعد','Student123!',null),
('student08','student','عمر ياسر','Student123!',null),
('student09','student','رؤى فهد','Student123!',null),
('student10','student','ياسر ناظم','Student123!',null),
('student11','student','ليان مازن','Student123!',null),
('student12','student','كرار فؤاد','Student123!',null);

insert into public.schools(id,name,timezone) values ('00000000-0000-0000-0000-000000000001','مدرسة النور النموذجية','Asia/Baghdad') on conflict do nothing;
insert into public.classes(id,school_id,grade,section) values
('00000000-0000-0000-0000-000000000101','00000000-0000-0000-0000-000000000001','الصف الأول','أ'),
('00000000-0000-0000-0000-000000000102','00000000-0000-0000-0000-000000000001','الصف الثاني','أ'),
('00000000-0000-0000-0000-000000000103','00000000-0000-0000-0000-000000000001','الصف الثالث','أ') on conflict do nothing;

insert into public.subjects(id,school_id,name) values
('00000000-0000-0000-0000-000000000201','00000000-0000-0000-0000-000000000001','الرياضيات'),
('00000000-0000-0000-0000-000000000202','00000000-0000-0000-0000-000000000001','اللغة العربية'),
('00000000-0000-0000-0000-000000000203','00000000-0000-0000-0000-000000000001','العلوم') on conflict do nothing;

insert into public.evaluation_periods(id,school_id,name,sort_order,max_score) values
('00000000-0000-0000-0000-000000000301','00000000-0000-0000-0000-000000000001','الشهر الأول',1,100),
('00000000-0000-0000-0000-000000000302','00000000-0000-0000-0000-000000000001','الشهر الثاني',2,100),
('00000000-0000-0000-0000-000000000303','00000000-0000-0000-0000-000000000001','نصف السنة',3,100),
('00000000-0000-0000-0000-000000000304','00000000-0000-0000-0000-000000000001','الشهر الثالث',4,100),
('00000000-0000-0000-0000-000000000305','00000000-0000-0000-0000-000000000001','الشهر الرابع',5,100),
('00000000-0000-0000-0000-000000000306','00000000-0000-0000-0000-000000000001','نهاية السنة',6,100) on conflict do nothing;
insert into public.evaluation_thresholds(school_id,label,min_score,sort_order) values
('00000000-0000-0000-0000-000000000001','ممتاز',90,1),('00000000-0000-0000-0000-000000000001','جيد جداً',80,2),('00000000-0000-0000-0000-000000000001','جيد',70,3),('00000000-0000-0000-0000-000000000001','متوسط',60,4),('00000000-0000-0000-0000-000000000001','مقبول',50,5),('00000000-0000-0000-0000-000000000001','ضعيف',0,6) on conflict do nothing;

-- Local Supabase supports creating auth users in SQL for deterministic demos.
create temporary table _auth_map(username text, uid uuid);
insert into _auth_map values
('mainadmin','10000000-0000-0000-0000-000000000001'),('adminrestricted','10000000-0000-0000-0000-000000000002'),('teacher_a','10000000-0000-0000-0000-000000000003'),('teacher_b','10000000-0000-0000-0000-000000000004'),('teacher_c','10000000-0000-0000-0000-000000000005'),
('student01','10000000-0000-0000-0000-000000000011'),('student02','10000000-0000-0000-0000-000000000012'),('student03','10000000-0000-0000-0000-000000000013'),('student04','10000000-0000-0000-0000-000000000014'),('student05','10000000-0000-0000-0000-000000000015'),('student06','10000000-0000-0000-0000-000000000016'),('student07','10000000-0000-0000-0000-000000000017'),('student08','10000000-0000-0000-0000-000000000018'),('student09','10000000-0000-0000-0000-000000000019'),('student10','10000000-0000-0000-0000-000000000020'),('student11','10000000-0000-0000-0000-000000000021'),('student12','10000000-0000-0000-0000-000000000022');

insert into auth.users(id,instance_id,aud,role,email,encrypted_password,email_confirmed_at,created_at,updated_at,raw_app_meta_data,raw_user_meta_data,confirmation_token,email_change,phone_change) 
select m.uid,'00000000-0000-0000-0000-000000000000','authenticated','authenticated',u.username || '@demo.local',crypt(u.password, gen_salt('bf')),now(),now(),now(),'{"provider":"email","providers":["email"]}'::jsonb,json_build_object('username',u.username)::jsonb,'','','' from _seed_users u join _auth_map m on m.username=u.username
on conflict (id) do nothing;

insert into public.profiles(id,school_id,role,admin_access,username,full_name,auth_email,must_change_password)
select m.uid,'00000000-0000-0000-0000-000000000001',u.role,u.admin_access,u.username,u.full_name,u.username || '@demo.local',true
from _seed_users u join _auth_map m on m.username=u.username
on conflict (id) do nothing;

insert into public.students(profile_id,school_id,class_id)
select p.id,p.school_id,case when p.username in ('student01','student02','student03','student04') then '00000000-0000-0000-0000-000000000101'::uuid when p.username in ('student05','student06','student07','student08') then '00000000-0000-0000-0000-000000000102'::uuid else '00000000-0000-0000-0000-000000000103'::uuid end
from public.profiles p where p.role='student' on conflict (profile_id) do nothing;

insert into public.account_class_links(account_id,class_id) values
('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000101'),
('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000101'),
('10000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000102'),
('10000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000103') on conflict do nothing;
insert into public.account_student_links(account_id,student_id)
select '10000000-0000-0000-0000-000000000003',id from public.students s join public.profiles p on p.id=s.profile_id where p.username='student04' on conflict do nothing;
insert into public.account_student_links(account_id,student_id)
select '10000000-0000-0000-0000-000000000004',id from public.students s join public.profiles p on p.id=s.profile_id where p.username='student05' on conflict do nothing;
insert into public.account_student_links(account_id,student_id)
select '10000000-0000-0000-0000-000000000005',id from public.students s join public.profiles p on p.id=s.profile_id where p.username='student09' on conflict do nothing;
insert into public.teacher_subjects values
('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000201'),
('10000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000202'),
('10000000-0000-0000-0000-000000000005','00000000-0000-0000-0000-000000000203') on conflict do nothing;

-- Demo content is inserted as the main admin.
insert into public.homework(id,school_id,publisher_id,title,subject_id,description,due_at)
values ('00000000-0000-0000-0000-000000000401','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','حل تدريبات الوحدة الأولى','00000000-0000-0000-0000-000000000201','حل التدريبات من 1 إلى 10.',now()+interval '2 days') on conflict do nothing;
insert into public.homework_class_targets values ('00000000-0000-0000-0000-000000000401','00000000-0000-0000-0000-000000000101') on conflict do nothing;
insert into public.announcements(id,school_id,publisher_id,title,body,priority,audience,is_pinned)
values ('00000000-0000-0000-0000-000000000501','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','مرحباً بكم','هذا تبليغ تجريبي للنظام.','important','everyone',true) on conflict do nothing;

insert into public.evaluations(school_id,student_id,subject_id,period_id,teacher_id,score,teacher_note)
select s.school_id,s.id,'00000000-0000-0000-0000-000000000201','00000000-0000-0000-0000-000000000301','10000000-0000-0000-0000-000000000003',score,note
from (values ('student01',95,'أداء ممتاز'),('student02',88,'عمل جيد'),('student03',76,'يحتاج إلى مزيد من التدريب'),('student04',91,'تقدم واضح'),('student05',83,'جيد جداً'),('student06',72,'تحسن ملحوظ'),('student07',90,'أداء ممتاز'),('student08',68,'يحتاج متابعة'),('student09',84,'جيد جداً'),('student10',79,'جيد'),('student11',93,'ممتاز'),('student12',65,'يحتاج إلى دعم')) v(username,score,note)
join public.profiles p on p.username=v.username join public.students s on s.profile_id=p.id on conflict do nothing;
