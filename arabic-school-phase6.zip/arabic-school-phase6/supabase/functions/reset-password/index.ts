import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  try {
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const token = (req.headers.get('Authorization') || '').replace('Bearer ', '');
    const { data: { user } } = await admin.auth.getUser(token);
    if (!user) return Response.json({ error: 'غير مصرح' }, { status: 401 });
    const { data: actor } = await admin.from('profiles').select('school_id,role,admin_access').eq('id', user.id).single();
    if (!actor || actor.role !== 'admin' || actor.admin_access !== 'full') return Response.json({ error: 'ليس لديك صلاحية' }, { status: 403 });
    const { userId, temporaryPassword } = await req.json();
    const { data: target } = await admin.from('profiles').select('school_id').eq('id', userId).single();
    if (!target || target.school_id !== actor.school_id) return Response.json({ error: 'الحساب غير موجود' }, { status: 404 });
    const { error } = await admin.auth.admin.updateUserById(userId, { password: temporaryPassword });
    if (error) throw error;
    await admin.from('profiles').update({ must_change_password: true }).eq('id', userId);
    await admin.from('audit_logs').insert({ school_id: actor.school_id, actor_id: user.id, action: 'reset_password', table_name: 'profiles', record_id: userId });
    return Response.json({ ok: true });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : 'حدث خطأ' }, { status: 400 }); }
});
