import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin = createClient(supabaseUrl, serviceKey);
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return new Response(JSON.stringify({ error: 'غير مصرح' }), { status: 401, headers: { ...cors, 'Content-Type': 'application/json' } });
    const token = authHeader.replace('Bearer ', '');
    const { data: { user } } = await admin.auth.getUser(token);
    if (!user) return new Response(JSON.stringify({ error: 'غير مصرح' }), { status: 401, headers: { ...cors, 'Content-Type': 'application/json' } });

    const { data: actor } = await admin.from('profiles').select('id, role, admin_access, school_id, is_active').eq('id', user.id).single();
    if (!actor || actor.role !== 'admin' || actor.admin_access !== 'full' || !actor.is_active) return new Response(JSON.stringify({ error: 'ليس لديك صلاحية' }), { status: 403, headers: { ...cors, 'Content-Type': 'application/json' } });

    const body = await req.json();
    const role = body.role as 'admin' | 'teacher' | 'student';
    if (!['admin','teacher','student'].includes(role)) throw new Error('الدور غير صحيح');
    if (!body.username || !body.fullName || !body.temporaryPassword) throw new Error('البيانات المطلوبة ناقصة');
    const username = String(body.username).trim().toLowerCase();
    const email = `${username}@${actor.school_id}.school.local`;

    const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password: body.temporaryPassword, email_confirm: true, user_metadata: { username } });
    if (createError) throw createError;
    const { error: profileError } = await admin.from('profiles').insert({ id: created.user.id, school_id: actor.school_id, role, admin_access: role === 'admin' ? 'restricted' : null, username, full_name: body.fullName, auth_email: email, must_change_password: true });
    if (profileError) {
      await admin.auth.admin.deleteUser(created.user.id);
      throw profileError;
    }
    await admin.from('audit_logs').insert({ school_id: actor.school_id, actor_id: actor.id, action: 'create', table_name: 'profiles', record_id: created.user.id, metadata: { username, role } });
    return new Response(JSON.stringify({ ok: true, userId: created.user.id }), { headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'حدث خطأ' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
});
