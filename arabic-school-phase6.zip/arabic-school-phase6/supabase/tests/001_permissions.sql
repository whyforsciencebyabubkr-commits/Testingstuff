begin;
select plan(12);

-- Helper: emulate an authenticated Supabase request without using service role.
create or replace function pg_temp.as_user(uid uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub', uid::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);
  perform set_config('request.jwt.claims', json_build_object('sub',uid::text,'role','authenticated')::text, true);
end; $$;

set local role authenticated;

-- 1. Teacher A can see class A students, but not class B.
select pg_temp.as_user('10000000-0000-0000-0000-000000000003');
select is((select count(*)::int from public.students where class_id='00000000-0000-0000-0000-000000000101'), 4, 'Teacher A sees all four students in Class A');
select is((select count(*)::int from public.students where class_id='00000000-0000-0000-0000-000000000102'), 0, 'Teacher A cannot see Class B students');

-- 2. Teacher A cannot read another teacher’s homework.
select is((select count(*)::int from public.homework where publisher_id='10000000-0000-0000-0000-000000000004'), 0, 'Teacher A cannot read Teacher B homework');

-- 3. Teacher A cannot update Teacher B homework.
select throws_ok($sql$
  update public.homework set title='محاولة غير مسموحة' where publisher_id='10000000-0000-0000-0000-000000000004';
$sql$, null, null, 'Teacher A cannot update another teacher homework');

-- 4. Student only sees own student row.
select pg_temp.as_user('10000000-0000-0000-0000-000000000011');
select is((select count(*)::int from public.students), 1, 'Student sees exactly one student row');
select is((select count(*)::int from public.students where id <> (select id from public.students)), 0, 'Student cannot see another student');

-- 5. Student cannot read another student’s evaluation.
select is((select count(*)::int from public.evaluations where student_id <> (select id from public.students)), 0, 'Student cannot read another student evaluation');

-- 6. Student cannot publish announcements.
select throws_ok($sql$
  insert into public.announcements(school_id,publisher_id,title,body,audience) values ('00000000-0000-0000-0000-000000000001',auth.uid(),'ممنوع','محتوى','everyone');
$sql$, null, null, 'Student cannot publish announcements');

-- 7. Teacher cannot publish announcements.
select pg_temp.as_user('10000000-0000-0000-0000-000000000003');
select throws_ok($sql$
  insert into public.announcements(school_id,publisher_id,title,body,audience) values ('00000000-0000-0000-0000-000000000001',auth.uid(),'ممنوع','محتوى','targeted');
$sql$, null, null, 'Teacher cannot publish announcements');

-- 8. Restricted admin cannot target everyone.
select pg_temp.as_user('10000000-0000-0000-0000-000000000002');
select throws_ok($sql$
  insert into public.announcements(school_id,publisher_id,title,body,audience) values ('00000000-0000-0000-0000-000000000001',auth.uid(),'ممنوع','محتوى','everyone');
$sql$, null, null, 'Restricted admin cannot target everyone');

-- 9. Restricted admin can only see linked class.
select is((select count(*)::int from public.students where class_id='00000000-0000-0000-0000-000000000101'), 4, 'Restricted admin sees linked Class A');
select is((select count(*)::int from public.students where class_id='00000000-0000-0000-0000-000000000102'), 0, 'Restricted admin cannot see Class B');

-- 10. Student rank function returns one row only for self.
select pg_temp.as_user('10000000-0000-0000-0000-000000000011');
select is((select count(*)::int from public.get_my_student_rank('00000000-0000-0000-0000-000000000301')), 1, 'Student rank RPC returns one row for self');

select * from finish();
rollback;
