-- Phase 5 database smoke/security tests. Run with `supabase test db` after migrations.
begin;
select plan(6);
select has_table('public','evaluations','evaluations table exists');
select has_table('public','evaluation_periods','evaluation periods exist');
select has_table('public','evaluation_thresholds','evaluation thresholds exist');
select has_table('public','evaluation_publications','publication table exists');
select has_function('public','get_my_student_rank',array['uuid'],'private rank RPC exists');
select has_function('public','publish_evaluation_results',array['uuid','uuid'],'publication RPC exists');
select * from finish();
rollback;
