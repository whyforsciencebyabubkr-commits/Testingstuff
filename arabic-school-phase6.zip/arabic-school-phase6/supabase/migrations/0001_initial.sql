-- Phase 1: secure core schema. User-facing text is Arabic; code/comments remain English.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'teacher', 'student');
create type public.admin_access as enum ('full', 'restricted');
create type public.homework_status as enum ('active', 'archived');
create type public.announcement_priority as enum ('normal', 'important', 'urgent');

create table public.schools (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_path text,
  primary_color text not null default '#164e63',
  timezone text not null default 'Asia/Baghdad',
  show_rank_total boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  grade text not null,
  section text not null,
  created_at timestamptz not null default now(),
  unique (school_id, grade, section)
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  role public.app_role not null,
  admin_access public.admin_access,
  username text not null unique,
  full_name text not null,
  auth_email text not null unique,
  is_active boolean not null default true,
  must_change_password boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint admin_access_only_for_admin check ((role = 'admin') = (admin_access is not null)),
  constraint student_no_admin_access check (role <> 'student' or admin_access is null)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  profile_id uuid not null unique references public.profiles(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  unique (school_id, name)
);

create table public.account_class_links (
  account_id uuid not null references public.profiles(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (account_id, class_id)
);

create table public.account_student_links (
  account_id uuid not null references public.profiles(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (account_id, student_id)
);

create table public.teacher_subjects (
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (teacher_id, subject_id)
);

create table public.evaluation_periods (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  name text not null,
  sort_order integer not null,
  max_score numeric(6,2) not null default 100 check (max_score > 0),
  is_active boolean not null default true,
  unique (school_id, name),
  unique (school_id, sort_order)
);

create table public.evaluation_thresholds (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  label text not null,
  min_score numeric(6,2) not null,
  sort_order integer not null,
  unique (school_id, label),
  unique (school_id, sort_order)
);

create table public.homework (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  publisher_id uuid not null references public.profiles(id) on delete restrict,
  title text not null,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  description text not null default '',
  due_at timestamptz not null,
  status public.homework_status not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.homework_class_targets (
  homework_id uuid not null references public.homework(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  primary key (homework_id, class_id)
);

create table public.homework_student_targets (
  homework_id uuid not null references public.homework(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  primary key (homework_id, student_id)
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  publisher_id uuid not null references public.profiles(id) on delete restrict,
  title text not null,
  body text not null,
  priority public.announcement_priority not null default 'normal',
  expires_at timestamptz,
  is_pinned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.announcement_class_targets (
  announcement_id uuid not null references public.announcements(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  primary key (announcement_id, class_id)
);

create table public.announcement_student_targets (
  announcement_id uuid not null references public.announcements(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  primary key (announcement_id, student_id)
);

create table public.evaluations (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  period_id uuid not null references public.evaluation_periods(id) on delete restrict,
  teacher_id uuid not null references public.profiles(id) on delete restrict,
  score numeric(6,2) not null check (score >= 0),
  teacher_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, subject_id, period_id)
);

create table public.evaluation_publications (
  school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  period_id uuid not null references public.evaluation_periods(id) on delete cascade,
  published_by uuid not null references public.profiles(id) on delete restrict,
  published_at timestamptz not null default now(),
  primary key (class_id, period_id)
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  school_id uuid not null references public.schools(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  table_name text not null,
  record_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index idx_profiles_school_role on public.profiles(school_id, role);
create index idx_students_school_class on public.students(school_id, class_id);
create index idx_class_links_account on public.account_class_links(account_id);
create index idx_student_links_account on public.account_student_links(account_id);
create index idx_homework_school_due on public.homework(school_id, due_at);
create index idx_evaluations_student_period on public.evaluations(student_id, period_id);

create or replace function public.set_updated_at() returns trigger
language plpgsql security definer set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists schools_updated_at on public.schools;
create trigger schools_updated_at before update on public.schools for each row execute function public.set_updated_at();
drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
drop trigger if exists homework_updated_at on public.homework;
create trigger homework_updated_at before update on public.homework for each row execute function public.set_updated_at();
drop trigger if exists announcements_updated_at on public.announcements;
create trigger announcements_updated_at before update on public.announcements for each row execute function public.set_updated_at();
drop trigger if exists evaluations_updated_at on public.evaluations;
create trigger evaluations_updated_at before update on public.evaluations for each row execute function public.set_updated_at();

create or replace function public.my_profile()
returns public.profiles
language sql stable security definer set search_path = public
as $$ select p from public.profiles p where p.id = auth.uid() and p.is_active = true limit 1 $$;

create or replace function public.my_school_id() returns uuid
language sql stable security definer set search_path = public
as $$ select school_id from public.profiles where id = auth.uid() and is_active = true $$;

create or replace function public.my_role() returns public.app_role
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() and is_active = true $$;

create or replace function public.is_full_admin() returns boolean
language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin' and admin_access = 'full' and is_active) $$;

create or replace function public.can_access_class(target_class uuid) returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.classes c
    where c.id = target_class and c.school_id = public.my_school_id()
      and (public.is_full_admin()
        or exists(select 1 from public.account_class_links acl where acl.account_id = auth.uid() and acl.class_id = c.id)
        or exists(select 1 from public.students s join public.profiles p on p.id = s.profile_id where s.class_id = c.id and p.id = auth.uid() and p.role = 'student'))
  )
  or exists (
    select 1 from public.account_student_links asl
    join public.students s on s.id = asl.student_id
    where asl.account_id = auth.uid() and s.class_id = target_class and s.school_id = public.my_school_id()
  );
$$;

create or replace function public.can_access_student(target_student uuid) returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.students s
    where s.id = target_student and s.school_id = public.my_school_id()
      and (public.is_full_admin()
        or s.profile_id = auth.uid()
        or exists(select 1 from public.account_class_links acl where acl.account_id = auth.uid() and acl.class_id = s.class_id)
        or exists(select 1 from public.account_student_links asl where asl.account_id = auth.uid() and asl.student_id = s.id))
  );
$$;

create or replace function public.can_publish_homework() returns boolean
language sql stable security definer set search_path = public
as $$ select public.my_role() in ('admin','teacher') $$;

create or replace function public.can_manage_own_homework(homework_publisher uuid) returns boolean
language sql stable security definer set search_path = public
as $$ select public.is_full_admin() or homework_publisher = auth.uid() $$;

create or replace function public.audit_event(p_action text, p_table text, p_record uuid, p_metadata jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_logs(school_id, actor_id, action, table_name, record_id, metadata)
  values (public.my_school_id(), auth.uid(), p_action, p_table, p_record, coalesce(p_metadata, '{}'::jsonb));
end; $$;

-- Protect cross-school and role-specific scope links.
create or replace function public.validate_scope_link() returns trigger
language plpgsql security definer set search_path = public as $$
declare account public.profiles; target_school uuid;
begin
  select * into account from public.profiles where id = new.account_id;
  if account.id is null then raise exception 'scope account is invalid'; end if;
  if auth.uid() is not null and account.school_id is distinct from public.my_school_id() then raise exception 'scope account is invalid'; end if;
  if account.role not in ('admin','teacher') then raise exception 'students cannot receive scope links'; end if;
  if tg_table_name = 'account_class_links' then select school_id into target_school from public.classes where id = new.class_id;
  else select school_id into target_school from public.students where id = new.student_id; end if;
  if target_school is distinct from account.school_id then raise exception 'cross-school scope link'; end if;
  return new;
end; $$;

create trigger validate_class_scope before insert or update on public.account_class_links for each row execute function public.validate_scope_link();
create trigger validate_student_scope before insert or update on public.account_student_links for each row execute function public.validate_scope_link();

-- Only full-access admins can manage accounts/links. Main admin protection is enforced by trigger.
create or replace function public.protect_main_admin() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.role = 'admin' and old.admin_access = 'full' and old.username = 'mainadmin' then
    if tg_op = 'DELETE' then raise exception 'main admin cannot be deleted'; end if;
    if new.role <> 'admin' or new.admin_access <> 'full' or new.is_active = false then raise exception 'main admin cannot be restricted or deactivated'; end if;
  end if;
  return coalesce(new, old);
end; $$;
create trigger protect_main_admin before update or delete on public.profiles for each row execute function public.protect_main_admin();

-- RLS is the actual authorization boundary.
alter table public.schools enable row level security;
alter table public.classes enable row level security;
alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.subjects enable row level security;
alter table public.account_class_links enable row level security;
alter table public.account_student_links enable row level security;
alter table public.teacher_subjects enable row level security;
alter table public.evaluation_periods enable row level security;
alter table public.evaluation_thresholds enable row level security;
alter table public.homework enable row level security;
alter table public.homework_class_targets enable row level security;
alter table public.homework_student_targets enable row level security;
alter table public.announcements enable row level security;
alter table public.announcement_class_targets enable row level security;
alter table public.announcement_student_targets enable row level security;
alter table public.evaluations enable row level security;
alter table public.evaluation_publications enable row level security;
alter table public.audit_logs enable row level security;

create policy schools_read on public.schools for select using (id = public.my_school_id());
create policy schools_full_admin_update on public.schools for update using (public.is_full_admin()) with check (id = public.my_school_id());

create policy classes_read on public.classes for select using (public.can_access_class(id));
create policy classes_full_admin_write on public.classes for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy profiles_scoped_read on public.profiles for select using (
  id = auth.uid() or public.is_full_admin() or exists (select 1 from public.students s where s.profile_id = profiles.id and public.can_access_student(s.id))
);
create policy profiles_full_admin_write on public.profiles for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy students_scoped_read on public.students for select using (public.can_access_student(id));
create policy students_full_admin_write on public.students for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy subjects_scoped_read on public.subjects for select using (school_id = public.my_school_id());
create policy subjects_full_admin_write on public.subjects for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy class_links_read_own_or_full on public.account_class_links for select using (account_id = auth.uid() or public.is_full_admin());
create policy class_links_full_admin_write on public.account_class_links for all using (public.is_full_admin()) with check (public.is_full_admin());
create policy student_links_read_own_or_full on public.account_student_links for select using (account_id = auth.uid() or public.is_full_admin());
create policy student_links_full_admin_write on public.account_student_links for all using (public.is_full_admin()) with check (public.is_full_admin());

create policy teacher_subjects_read on public.teacher_subjects for select using (teacher_id = auth.uid() or public.is_full_admin());
create policy teacher_subjects_full_admin_write on public.teacher_subjects for all using (public.is_full_admin()) with check (public.is_full_admin());

create policy evaluation_periods_read on public.evaluation_periods for select using (school_id = public.my_school_id());
create policy evaluation_periods_full_admin_write on public.evaluation_periods for all using (public.is_full_admin()) with check (school_id = public.my_school_id());
create policy evaluation_thresholds_read on public.evaluation_thresholds for select using (school_id = public.my_school_id());
create policy evaluation_thresholds_full_admin_write on public.evaluation_thresholds for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy homework_read_scoped on public.homework for select using (
  school_id = public.my_school_id() and (
    public.is_full_admin()
    or publisher_id = auth.uid()
    or exists (select 1 from public.homework_class_targets hct where hct.homework_id = id and public.can_access_class(hct.class_id))
    or exists (select 1 from public.homework_student_targets hst where hst.homework_id = id and public.can_access_student(hst.student_id))
  )
);
create policy homework_insert_publishers on public.homework for insert with check (
  school_id = public.my_school_id() and public.can_publish_homework() and public.can_manage_own_homework(publisher_id)
);
create policy homework_update_owner_or_full on public.homework for update using (school_id = public.my_school_id() and public.can_manage_own_homework(publisher_id)) with check (school_id = public.my_school_id());
create policy homework_delete_owner_or_full on public.homework for delete using (school_id = public.my_school_id() and public.can_manage_own_homework(publisher_id));

create policy homework_class_targets_read on public.homework_class_targets for select using (exists(select 1 from public.homework h where h.id = homework_id));
create policy homework_class_targets_write on public.homework_class_targets for all using (
  exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id))
) with check (
  exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id) and public.can_access_class(class_id))
);
create policy homework_student_targets_read on public.homework_student_targets for select using (exists(select 1 from public.homework h where h.id = homework_id));
create policy homework_student_targets_write on public.homework_student_targets for all using (
  exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id))
) with check (
  exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id) and public.can_access_student(student_id))
);

-- Announcements are publishable only by admins. Restricted admins cannot create an unrestricted audience.
create policy announcements_read_scoped on public.announcements for select using (
  school_id = public.my_school_id() and (
    public.is_full_admin()
    or exists(select 1 from public.announcement_class_targets act where act.announcement_id = id and public.can_access_class(act.class_id))
    or exists(select 1 from public.announcement_student_targets ast where ast.announcement_id = id and public.can_access_student(ast.student_id))
  )
);
create policy announcements_admin_insert on public.announcements for insert with check (school_id = public.my_school_id() and public.my_role() = 'admin' and publisher_id = auth.uid());
create policy announcements_admin_update on public.announcements for update using (school_id = public.my_school_id() and public.is_full_admin()) with check (school_id = public.my_school_id());
create policy announcements_admin_delete on public.announcements for delete using (school_id = public.my_school_id() and public.is_full_admin());
create policy announcement_class_targets_read on public.announcement_class_targets for select using (exists(select 1 from public.announcements a where a.id = announcement_id));
create policy announcement_class_targets_write on public.announcement_class_targets for all using (exists(select 1 from public.announcements a where a.id = announcement_id and a.publisher_id = auth.uid() and public.my_role() = 'admin')) with check (exists(select 1 from public.announcements a where a.id = announcement_id and a.publisher_id = auth.uid() and public.my_role() = 'admin' and (public.is_full_admin() or public.can_access_class(class_id))));
create policy announcement_student_targets_read on public.announcement_student_targets for select using (exists(select 1 from public.announcements a where a.id = announcement_id));
create policy announcement_student_targets_write on public.announcement_student_targets for all using (exists(select 1 from public.announcements a where a.id = announcement_id and a.publisher_id = auth.uid() and public.my_role() = 'admin')) with check (exists(select 1 from public.announcements a where a.id = announcement_id and a.publisher_id = auth.uid() and public.my_role() = 'admin' and (public.is_full_admin() or public.can_access_student(student_id))));

create or replace function public.can_see_evaluation(target_student uuid, target_period uuid) returns boolean
language sql stable security definer set search_path = public
as $$
  select public.can_access_student(target_student)
    and (public.my_role() in ('admin','teacher')
      or exists (
        select 1 from public.students s
        join public.evaluation_publications ep on ep.class_id = s.class_id and ep.period_id = target_period
        where s.id = target_student
      ));
$$;

create policy evaluations_read_scoped on public.evaluations for select using (school_id = public.my_school_id() and public.can_see_evaluation(student_id, period_id));
create policy evaluations_teacher_write on public.evaluations for insert with check (
  school_id = public.my_school_id() and public.my_role() = 'teacher' and teacher_id = auth.uid()
  and public.can_access_student(student_id)
  and exists(select 1 from public.teacher_subjects ts where ts.teacher_id = auth.uid() and ts.subject_id = subject_id)
);
create policy evaluations_teacher_update on public.evaluations for update using (
  school_id = public.my_school_id() and ((public.my_role() = 'teacher' and teacher_id = auth.uid()) or public.is_full_admin()) and public.can_access_student(student_id)
) with check (school_id = public.my_school_id() and (public.is_full_admin() or teacher_id = auth.uid()));
create policy evaluations_admin_delete on public.evaluations for delete using (public.is_full_admin());

create policy publications_read_own_class on public.evaluation_publications for select using (school_id = public.my_school_id() and (public.is_full_admin() or public.can_access_class(class_id)));
create policy publications_full_admin_write on public.evaluation_publications for all using (public.is_full_admin()) with check (school_id = public.my_school_id());

create policy audit_full_admin_read on public.audit_logs for select using (public.is_full_admin());
create policy audit_insert_authenticated on public.audit_logs for insert with check (school_id = public.my_school_id() and actor_id = auth.uid());

-- Force the database to reject out-of-school/cross-role direct writes even if a future policy is accidentally broadened.
create or replace function public.validate_school_consistency() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_table_name = 'students' and (select school_id from public.classes where id = new.class_id) is distinct from new.school_id then raise exception 'cross-school student'; end if;
  if tg_table_name = 'homework' and (select school_id from public.subjects where id = new.subject_id) is distinct from new.school_id then raise exception 'cross-school homework'; end if;
  if tg_table_name = 'evaluations' and ((select school_id from public.students where id = new.student_id) is distinct from new.school_id or (select school_id from public.subjects where id = new.subject_id) is distinct from new.school_id) then raise exception 'cross-school evaluation'; end if;
  return new;
end; $$;
create trigger students_school_check before insert or update on public.students for each row execute function public.validate_school_consistency();
create trigger homework_school_check before insert or update on public.homework for each row execute function public.validate_school_consistency();
create trigger evaluations_school_check before insert or update on public.evaluations for each row execute function public.validate_school_consistency();

-- Announcement audience model.
alter table public.announcements add column audience text not null default 'targeted' check (audience in ('everyone','students','teachers','targeted'));

create or replace function public.can_see_homework(target_homework uuid) returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.homework h
    where h.id = target_homework and h.school_id = public.my_school_id()
      and (public.is_full_admin() or h.publisher_id = auth.uid()
        or exists(select 1 from public.homework_class_targets t where t.homework_id = h.id and public.can_access_class(t.class_id))
        or exists(select 1 from public.homework_student_targets t where t.homework_id = h.id and public.can_access_student(t.student_id)))
  );
$$;

create or replace function public.can_see_announcement(target_announcement uuid) returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.announcements a
    where a.id = target_announcement and a.school_id = public.my_school_id()
      and (public.is_full_admin()
        or (a.audience = 'students' and public.my_role() = 'student')
        or (a.audience = 'teachers' and public.my_role() = 'teacher')
        or (a.audience = 'everyone' and public.my_role() in ('admin','teacher','student'))
        or (a.audience = 'targeted' and (
          exists(select 1 from public.announcement_class_targets t where t.announcement_id = a.id and public.can_access_class(t.class_id))
          or exists(select 1 from public.announcement_student_targets t where t.announcement_id = a.id and public.can_access_student(t.student_id))
        )))
  );
$$;

drop policy if exists homework_read_scoped on public.homework;
create policy homework_read_scoped on public.homework for select using (public.can_see_homework(id));

drop policy if exists announcements_read_scoped on public.announcements;
create policy announcements_read_scoped on public.announcements for select using (public.can_see_announcement(id));

create or replace function public.validate_announcement_audience() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.audience = 'everyone' and not public.is_full_admin() then raise exception 'restricted admin cannot target everyone'; end if;
  if auth.uid() is not null and new.audience = 'students' and public.my_role() <> 'admin' then raise exception 'only admins publish announcements'; end if;
  if auth.uid() is not null and new.audience = 'teachers' and public.my_role() <> 'admin' then raise exception 'only admins publish announcements'; end if;
  if auth.uid() is not null and new.audience = 'targeted' and public.my_role() <> 'admin' then raise exception 'only admins publish announcements'; end if;
  return new;
end; $$;
create trigger validate_announcement_audience before insert or update on public.announcements for each row execute function public.validate_announcement_audience();

create or replace function public.validate_homework_target() returns trigger
language plpgsql security definer set search_path = public as $$
declare h public.homework;
begin
  select * into h from public.homework where id = coalesce(new.homework_id, old.homework_id);
  if h.id is null then raise exception 'homework not found'; end if;
  return new;
end; $$;

-- Server-only rank function. It returns one row for the requesting student and never exposes classmates.
create or replace function public.get_my_student_rank(p_period_id uuid default null)
returns table(rank bigint, total_students bigint)
language sql stable security definer set search_path = public
as $$
with me as (
  select s.id student_id, s.class_id, s.school_id from public.students s where s.profile_id = auth.uid()
), scores as (
  select e.student_id, avg(e.score) average_score
  from public.evaluations e join me m on m.class_id = (select class_id from public.students where id = e.student_id)
  where e.school_id = (select school_id from me)
    and (p_period_id is null or e.period_id = p_period_id)
  group by e.student_id
), ranked as (
  select s.student_id, dense_rank() over(order by s.average_score desc) as rank,
         count(*) over() as total_students
  from scores s
)
select r.rank, r.total_students from ranked r where r.student_id = (select student_id from me);
$$;

revoke all on function public.get_my_student_rank(uuid) from public;
grant execute on function public.get_my_student_rank(uuid) to authenticated;
