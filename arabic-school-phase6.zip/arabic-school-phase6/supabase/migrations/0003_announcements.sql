-- Phase 4: announcement read receipts, attachments, and scope validation.
create table public.announcement_reads (
  announcement_id uuid not null references public.announcements(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (announcement_id, user_id)
);
create index announcement_reads_user_idx on public.announcement_reads(user_id, read_at desc);
alter table public.announcement_reads enable row level security;
create policy announcement_reads_recipient_read on public.announcement_reads for select using (
 school_id = public.my_school_id() and (user_id = auth.uid() or public.is_full_admin())
);
create policy announcement_reads_self_insert on public.announcement_reads for insert with check (
 school_id = public.my_school_id() and user_id = auth.uid() and public.can_see_announcement(announcement_id)
);

create table public.announcement_attachments (
 id uuid primary key default gen_random_uuid(),
 school_id uuid not null references public.schools(id) on delete cascade,
 announcement_id uuid not null references public.announcements(id) on delete cascade,
 uploaded_by uuid not null references public.profiles(id) on delete restrict,
 storage_path text not null unique,
 file_name text not null,
 mime_type text not null check (mime_type in ('image/jpeg','image/png','image/webp','application/pdf')),
 size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 10485760),
 created_at timestamptz not null default now()
);
alter table public.announcement_attachments enable row level security;
create policy announcement_attachments_read_recipient on public.announcement_attachments for select using (
 school_id = public.my_school_id() and public.can_see_announcement(announcement_id)
);
create policy announcement_attachments_insert_admin on public.announcement_attachments for insert with check (
 school_id = public.my_school_id() and uploaded_by = auth.uid() and public.my_role() = 'admin'
 and exists(select 1 from public.announcements a where a.id = announcement_id and a.publisher_id = auth.uid())
);
create policy announcement_attachments_delete_admin on public.announcement_attachments for delete using (
 school_id = public.my_school_id() and public.my_role() = 'admin'
 and exists(select 1 from public.announcements a where a.id = announcement_id and (a.publisher_id = auth.uid() or public.is_full_admin()))
);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('announcement-files','announcement-files',false,10485760,array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public=false,file_size_limit=10485760,allowed_mime_types=array['image/jpeg','image/png','image/webp','application/pdf'];
create policy announcement_files_read_recipients on storage.objects for select using (
 bucket_id='announcement-files' and public.can_see_announcement(((storage.foldername(name))[2])::uuid)
);
create policy announcement_files_insert_admin on storage.objects for insert with check (
 bucket_id='announcement-files' and (storage.foldername(name))[1]=public.my_school_id()::text
 and public.my_role()='admin' and exists(select 1 from public.announcements a where a.id=((storage.foldername(name))[2])::uuid and a.publisher_id=auth.uid())
);
create policy announcement_files_delete_admin on storage.objects for delete using (
 bucket_id='announcement-files' and (storage.foldername(name))[1]=public.my_school_id()::text
 and public.my_role()='admin' and exists(select 1 from public.announcements a where a.id=((storage.foldername(name))[2])::uuid and (a.publisher_id=auth.uid() or public.is_full_admin()))
);

create or replace function public.validate_announcement_audience() returns trigger
language plpgsql security definer set search_path = public as $$
declare school_of_class uuid; school_of_student uuid;
begin
 if auth.uid() is not null and public.my_role() <> 'admin' then raise exception 'only admins publish announcements'; end if;
 if new.school_id <> public.my_school_id() then raise exception 'wrong school'; end if;
 if new.publisher_id <> auth.uid() and not public.is_full_admin() then raise exception 'publisher mismatch'; end if;
 if auth.uid() is not null and new.audience='everyone' and not public.is_full_admin() then raise exception 'restricted admin cannot target everyone'; end if;
 if auth.uid() is not null and new.audience in ('students','teachers') and not public.is_full_admin() then raise exception 'restricted admin must target within scope'; end if;
 if new.audience in ('students','teachers') and public.my_role()<>'admin' then raise exception 'only admins publish announcements'; end if;
 if new.audience='targeted' and not public.is_full_admin() then
   if not exists(select 1 from public.announcement_class_targets t where t.announcement_id=new.id)
      and not exists(select 1 from public.announcement_student_targets t where t.announcement_id=new.id) then
     -- Targets are inserted after the announcement row, so audience target validation is enforced by target triggers below.
     null;
   end if;
 end if;
 return new;
end; $$;
-- Audience trigger is deferred to permit creating an announcement before its target rows.
drop trigger if exists validate_announcement_audience on public.announcements;
create constraint trigger validate_announcement_audience after insert or update on public.announcements
 deferrable initially deferred for each row execute function public.validate_announcement_audience();

create or replace function public.validate_announcement_target_scope() returns trigger
language plpgsql security definer set search_path = public as $$
declare a public.announcements; target_school uuid;
begin
 select * into a from public.announcements where id=new.announcement_id;
 if a.id is null or a.school_id<>public.my_school_id() or public.my_role()<>'admin' then raise exception 'not allowed'; end if;
 if not public.is_full_admin() and a.audience='everyone' then raise exception 'restricted admin cannot target everyone'; end if;
 if tg_table_name='announcement_class_targets' then
   select school_id into target_school from public.classes where id=new.class_id;
   if target_school is distinct from a.school_id or (not public.is_full_admin() and not public.can_access_class(new.class_id)) then raise exception 'class outside scope'; end if;
 else
   select school_id into target_school from public.students where id=new.student_id;
   if target_school is distinct from a.school_id or (not public.is_full_admin() and not public.can_access_student(new.student_id)) then raise exception 'student outside scope'; end if;
 end if;
 return new;
end; $$;
drop trigger if exists announcement_class_target_scope on public.announcement_class_targets;
create trigger announcement_class_target_scope before insert or update on public.announcement_class_targets for each row execute function public.validate_announcement_target_scope();
drop trigger if exists announcement_student_target_scope on public.announcement_student_targets;
create trigger announcement_student_target_scope before insert or update on public.announcement_student_targets for each row execute function public.validate_announcement_target_scope();

create or replace function public.audit_event(p_action text,p_table text,p_record uuid,p_metadata jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public as $$
begin
 insert into public.audit_logs(school_id,actor_id,action,table_name,record_id,metadata)
 values(public.my_school_id(),auth.uid(),p_action,p_table,p_record,coalesce(p_metadata,'{}'::jsonb));
end; $$;
-- Authors may manage their own announcements; full-access admins may manage all in their school.
drop policy if exists announcements_admin_update on public.announcements;
create policy announcements_admin_update on public.announcements for update using (
 school_id=public.my_school_id() and public.my_role()='admin' and (public.is_full_admin() or publisher_id=auth.uid())
) with check (school_id=public.my_school_id() and public.my_role()='admin' and (public.is_full_admin() or publisher_id=auth.uid()));
drop policy if exists announcements_admin_delete on public.announcements;
create policy announcements_admin_delete on public.announcements for delete using (
 school_id=public.my_school_id() and public.my_role()='admin' and (public.is_full_admin() or publisher_id=auth.uid())
);
-- Return aggregate read statistics only; never expose recipient identities through this RPC.
create or replace function public.get_announcement_read_stats(p_announcement_id uuid)
returns table(read_count bigint, recipient_count bigint)
language sql stable security definer set search_path=public as $$
with a as (
 select * from public.announcements where id=p_announcement_id and school_id=public.my_school_id()
   and public.my_role()='admin' and (public.is_full_admin() or publisher_id=auth.uid())
), recipients as (
 select p.id from public.profiles p,a where p.school_id=a.school_id and p.is_active and (
   (a.audience='everyone' and p.role in ('admin','teacher','student'))
   or (a.audience='students' and p.role='student')
   or (a.audience='teachers' and p.role='teacher')
   or (a.audience='targeted' and (
      exists(select 1 from public.students s join public.announcement_class_targets ct on ct.class_id=s.class_id where s.profile_id=p.id and ct.announcement_id=a.id)
      or exists(select 1 from public.students s join public.announcement_student_targets st on st.student_id=s.id where s.profile_id=p.id and st.announcement_id=a.id)
   ))
 )
)
select (select count(*) from public.announcement_reads r join a on a.id=r.announcement_id), (select count(*) from recipients);
$$;
grant execute on function public.get_announcement_read_stats(uuid) to authenticated;
-- Do not reveal target classes or student identifiers outside the viewer's scope.
drop policy if exists announcement_class_targets_read on public.announcement_class_targets;
create policy announcement_class_targets_read on public.announcement_class_targets for select using (
 public.is_full_admin() or public.can_access_class(class_id)
);
drop policy if exists announcement_student_targets_read on public.announcement_student_targets;
create policy announcement_student_targets_read on public.announcement_student_targets for select using (
 public.is_full_admin() or public.can_access_student(student_id)
);
