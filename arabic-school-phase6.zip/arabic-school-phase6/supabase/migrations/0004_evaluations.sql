-- Phase 5: evaluation workflow hardening, class publication and private ranking.
create index if not exists idx_evaluations_school_period_subject on public.evaluations(school_id, period_id, subject_id);

-- Validate the evaluation's period, subject, student, and score ceiling at the database boundary.
create or replace function public.validate_evaluation_record() returns trigger
language plpgsql security definer set search_path = public as $$
declare student_school uuid; subject_school uuid; period_school uuid; ceiling numeric;
begin
  select school_id into student_school from public.students where id = new.student_id;
  select school_id into subject_school from public.subjects where id = new.subject_id;
  select school_id, max_score into period_school, ceiling from public.evaluation_periods where id = new.period_id;
  if student_school is distinct from new.school_id or subject_school is distinct from new.school_id or period_school is distinct from new.school_id then raise exception 'cross-school evaluation'; end if;
  if new.score > ceiling then raise exception 'score exceeds period maximum'; end if;
  if new.teacher_id is null then raise exception 'teacher is required'; end if;
  return new;
end; $$;
drop trigger if exists validate_evaluation_record on public.evaluations;
create trigger validate_evaluation_record before insert or update on public.evaluations for each row execute function public.validate_evaluation_record();

-- Full administrators may enter/correct grades too. Teachers remain limited by their class and subject links.
drop policy if exists evaluations_teacher_write on public.evaluations;
create policy evaluations_teacher_write on public.evaluations for insert with check (
  school_id = public.my_school_id() and (
    (public.my_role() = 'teacher' and teacher_id = auth.uid()
      and public.can_access_student(student_id)
      and exists(select 1 from public.teacher_subjects ts where ts.teacher_id = auth.uid() and ts.subject_id = evaluations.subject_id))
    or (public.is_full_admin() and teacher_id = auth.uid())
  )
);
drop policy if exists evaluations_teacher_update on public.evaluations;
create policy evaluations_teacher_update on public.evaluations for update using (
  school_id = public.my_school_id() and ((public.my_role() = 'teacher' and teacher_id = auth.uid() and public.can_access_student(student_id)
    and exists(select 1 from public.teacher_subjects ts where ts.teacher_id = auth.uid() and ts.subject_id = evaluations.subject_id)) or public.is_full_admin())
) with check (school_id = public.my_school_id() and (public.is_full_admin() or (teacher_id = auth.uid() and public.can_access_student(student_id) and exists(select 1 from public.teacher_subjects ts where ts.teacher_id=auth.uid() and ts.subject_id=evaluations.subject_id))));

-- A student can receive a rank only after their own class/period is published.
drop function if exists public.get_my_student_rank(uuid);
create function public.get_my_student_rank(p_period_id uuid default null)
returns table(rank bigint, total_students bigint, average_percentage numeric)
language sql stable security definer set search_path = public as $$
with me as (
  select s.id student_id, s.class_id, s.school_id from public.students s where s.profile_id = auth.uid()
), permitted as (
  select m.* from me m where p_period_id is not null and exists (
    select 1 from public.evaluation_publications ep where ep.class_id=m.class_id and ep.period_id=p_period_id and ep.school_id=m.school_id
  )
), scores as (
  select e.student_id, avg((e.score / nullif(ep.max_score,0))*100.0) average_score
  from public.evaluations e
  join permitted m on m.class_id = (select s.class_id from public.students s where s.id=e.student_id) and m.school_id=e.school_id
  join public.evaluation_periods ep on ep.id=e.period_id and ep.school_id=e.school_id
  where (p_period_id is null or e.period_id=p_period_id)
    and (p_period_id is null or exists(select 1 from public.evaluation_publications pub where pub.class_id=m.class_id and pub.period_id=p_period_id))
  group by e.student_id
), ranked as (
  select s.student_id, dense_rank() over(order by s.average_score desc) as place,
    count(*) over() as total, round(s.average_score,2) as avg_pct from scores s
)
select r.place, r.total, r.avg_pct from ranked r where r.student_id=(select student_id from permitted);
$$;
revoke all on function public.get_my_student_rank(uuid) from public;
grant execute on function public.get_my_student_rank(uuid) to authenticated;

create or replace function public.publish_evaluation_results(p_class_id uuid, p_period_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare sid uuid;
begin
  sid := public.my_school_id();
  if not public.is_full_admin() then raise exception 'not authorized'; end if;
  if not exists(select 1 from public.classes where id=p_class_id and school_id=sid) then raise exception 'invalid class'; end if;
  if not exists(select 1 from public.evaluation_periods where id=p_period_id and school_id=sid) then raise exception 'invalid period'; end if;
  insert into public.evaluation_publications(school_id,class_id,period_id,published_by)
  values(sid,p_class_id,p_period_id,auth.uid())
  on conflict(class_id,period_id) do update set published_by=excluded.published_by,published_at=now();
  perform public.audit_event('publish','evaluation_publications',p_class_id,jsonb_build_object('class_id',p_class_id,'period_id',p_period_id));
end; $$;
revoke all on function public.publish_evaluation_results(uuid,uuid) from public;
grant execute on function public.publish_evaluation_results(uuid,uuid) to authenticated;

-- Publication writes go through the audited RPC, not direct client table writes.
drop policy if exists publications_full_admin_write on public.evaluation_publications;
create or replace function public.validate_evaluation_publication() returns trigger
language plpgsql security definer set search_path = public as $$
declare class_school uuid; period_school uuid;
begin
  select school_id into class_school from public.classes where id=new.class_id;
  select school_id into period_school from public.evaluation_periods where id=new.period_id;
  if class_school is distinct from new.school_id or period_school is distinct from new.school_id then raise exception 'cross-school evaluation publication'; end if;
  return new;
end; $$;
drop trigger if exists validate_evaluation_publication on public.evaluation_publications;
create trigger validate_evaluation_publication before insert or update on public.evaluation_publications for each row execute function public.validate_evaluation_publication();
