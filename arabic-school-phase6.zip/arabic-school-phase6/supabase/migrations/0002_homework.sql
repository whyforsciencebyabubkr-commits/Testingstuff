-- Phase 3: homework audiences, private attachments, and server-enforced scope.
create table public.homework_attachments (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  homework_id uuid not null references public.homework(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id) on delete restrict,
  storage_path text not null unique,
  file_name text not null,
  mime_type text not null check (mime_type in ('image/jpeg','image/png','image/webp','application/pdf')),
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 10485760),
  created_at timestamptz not null default now()
);
create index homework_targets_class_idx on public.homework_class_targets(class_id);
create index homework_targets_student_idx on public.homework_student_targets(student_id);
create index homework_attachments_homework_idx on public.homework_attachments(homework_id);
alter table public.homework_attachments enable row level security;

-- Teachers may only publish assigned subjects and all targets must be inside their account scope.
create or replace function public.validate_homework_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare subject_school uuid;
begin
  if new.school_id <> public.my_school_id() then raise exception 'wrong school'; end if;
  if public.my_role() not in ('admin','teacher') then raise exception 'homework publishing is not allowed'; end if;
  if new.publisher_id <> auth.uid() and not public.is_full_admin() then raise exception 'publisher mismatch'; end if;
  select school_id into subject_school from public.subjects where id = new.subject_id;
  if subject_school is distinct from new.school_id then raise exception 'subject belongs to another school'; end if;
  if public.my_role() = 'teacher' and not exists (
    select 1 from public.teacher_subjects ts where ts.teacher_id = auth.uid() and ts.subject_id = new.subject_id
  ) then raise exception 'teacher is not assigned to this subject'; end if;
  return new;
end; $$;
drop trigger if exists homework_write_validation on public.homework;
create trigger homework_write_validation before insert or update on public.homework for each row execute function public.validate_homework_write();

create or replace function public.validate_homework_target_scope() returns trigger
language plpgsql security definer set search_path = public as $$
declare h public.homework; target_school uuid;
begin
  select * into h from public.homework where id = new.homework_id;
  if h.id is null then raise exception 'homework not found'; end if;
  if h.school_id <> public.my_school_id() or not public.can_manage_own_homework(h.publisher_id) then raise exception 'not allowed to change this homework'; end if;
  if tg_table_name = 'homework_class_targets' then
    select school_id into target_school from public.classes where id = new.class_id;
    if target_school is distinct from h.school_id or not public.can_access_class(new.class_id) then raise exception 'class outside scope'; end if;
  else
    select school_id into target_school from public.students where id = new.student_id;
    if target_school is distinct from h.school_id or not public.can_access_student(new.student_id) then raise exception 'student outside scope'; end if;
  end if;
  return new;
end; $$;
drop trigger if exists homework_class_target_scope on public.homework_class_targets;
create trigger homework_class_target_scope before insert or update on public.homework_class_targets for each row execute function public.validate_homework_target_scope();
drop trigger if exists homework_student_target_scope on public.homework_student_targets;
create trigger homework_student_target_scope before insert or update on public.homework_student_targets for each row execute function public.validate_homework_target_scope();

create policy homework_attachments_read on public.homework_attachments for select using (school_id = public.my_school_id() and public.can_see_homework(homework_id));
create policy homework_attachments_insert on public.homework_attachments for insert with check (
 school_id = public.my_school_id() and uploaded_by = auth.uid() and exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id))
);
create policy homework_attachments_delete on public.homework_attachments for delete using (
 school_id = public.my_school_id() and exists(select 1 from public.homework h where h.id = homework_id and public.can_manage_own_homework(h.publisher_id))
);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('homework-files','homework-files',false,10485760,array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set public=false, file_size_limit=10485760, allowed_mime_types=array['image/jpeg','image/png','image/webp','application/pdf'];
create policy homework_files_read_recipients on storage.objects for select using (
 bucket_id = 'homework-files' and public.can_see_homework(((storage.foldername(name))[2])::uuid)
);
create policy homework_files_insert_publishers on storage.objects for insert with check (
 bucket_id = 'homework-files' and (storage.foldername(name))[1] = public.my_school_id()::text
 and exists(select 1 from public.homework h where h.id = ((storage.foldername(name))[2])::uuid and public.can_manage_own_homework(h.publisher_id))
);
create policy homework_files_delete_publishers on storage.objects for delete using (
 bucket_id = 'homework-files' and (storage.foldername(name))[1] = public.my_school_id()::text
 and exists(select 1 from public.homework h where h.id = ((storage.foldername(name))[2])::uuid and public.can_manage_own_homework(h.publisher_id))
);

-- Do not expose target identifiers outside the caller's own scope.
drop policy if exists homework_class_targets_read on public.homework_class_targets;
create policy homework_class_targets_read on public.homework_class_targets for select using (
  exists(select 1 from public.homework h where h.id = homework_id) and public.can_access_class(class_id)
);
drop policy if exists homework_student_targets_read on public.homework_student_targets;
create policy homework_student_targets_read on public.homework_student_targets for select using (
  exists(select 1 from public.homework h where h.id = homework_id) and public.can_access_student(student_id)
);
