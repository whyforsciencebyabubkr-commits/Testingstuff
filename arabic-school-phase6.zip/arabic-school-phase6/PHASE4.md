# Phase 4 — Announcements

## Delivered
- Arabic RTL announcement feed and detail page.
- Priority labels: normal, important, urgent; pinned announcements first; expired announcements hidden from the feed.
- Admin-only create, edit, and delete actions, with a confirmation before deletion.
- Audience choices for full-access admins: everyone, students, teachers, or selected classes/students. Restricted admins can target only classes/students inside their scope; the server/database reject broad audiences and out-of-scope targets.
- Optional expiry and pin-to-top settings.
- One optional image/PDF attachment (10 MB maximum) stored in a private bucket; recipients receive short-lived signed URLs.
- Opening a notice records a read receipt. The sidebar badge reflects unread announcements. Admins see aggregate read counts, not a list of reader identities.
- Audit events for creation, edit, and deletion.
- SQL checks in `supabase/tests/003_announcements.sql`.

## Run locally
1. Copy `.env.example` to `.env.local` and configure Supabase.
2. Run `npm install`.
3. Run `npm run supabase:start` and `npm run supabase:reset`.
4. Run `npm run typecheck`, `npm run build`, and `npm run supabase:test`.
5. Run `npm run dev`, sign in as an admin, and open `/announcements`.

Demo logins are in `supabase/seed.sql`; for example `mainadmin` / `MainAdmin123!`. Local demo accounts are not production credentials.

## Manual permission checks
- Teacher/student attempts to create an announcement are rejected by server action and database RLS.
- Restricted admin has no `everyone`, `students only`, or `teachers only` audience option; direct requests are rejected by a database trigger.
- Restricted admin targeting a class/student outside their scope is rejected by RLS/trigger.
- Student A cannot select announcement rows or attachment files outside their audience.
- Open an announcement as a recipient, return to the list, and confirm the unread badge decrements.
- Confirm an admin sees read counts in aggregate and never receives reader names from the stats RPC.
- Expired announcements should not appear in the feed; pinned notices should appear before non-pinned notices.

## Verification status / limitations
- `npm install --ignore-scripts --no-audit --no-fund` timed out in this environment. Therefore TypeScript build and Supabase integration tests could not be executed here; they must pass in a network-enabled local environment before production deployment.
- The read-statistics RPC intentionally returns only aggregate counts. Announcement target changes are currently managed at creation time; editing title/body/priority/expiry/pin is supported, while changing the audience after publishing is not included yet.
