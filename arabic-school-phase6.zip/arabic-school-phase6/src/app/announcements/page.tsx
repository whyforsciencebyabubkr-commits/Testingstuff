import Link from 'next/link';
import {getCurrentProfile} from '@/lib/auth';
import {createSupabaseServer} from '@/lib/supabase-server';
import {AppShell} from '@/components/app-shell';
const priority:{[key:string]:{label:string;icon:string;className:string}}={normal:{label:'عادي',icon:'●',className:'priority-normal'},important:{label:'مهم',icon:'◆',className:'priority-important'},urgent:{label:'عاجل',icon:'⚠',className:'priority-urgent'}};
export default async function AnnouncementsPage({searchParams}:{searchParams:Promise<{error?:string}>}){
 const profile=await getCurrentProfile();const params=await searchParams;const supabase=await createSupabaseServer();
 const [{data:school},{data:items},{data:reads}]=await Promise.all([
 supabase.from('schools').select('name').eq('id',profile.schoolId).maybeSingle(),
 supabase.from('announcements').select('id,title,body,priority,audience,is_pinned,created_at,expires_at,publisher_id,profiles!announcements_publisher_id_fkey(full_name),announcement_reads(user_id,read_at)').eq('school_id',profile.schoolId).order('is_pinned',{ascending:false}).order('created_at',{ascending:false}),
 supabase.from('announcement_reads').select('announcement_id,user_id').eq('school_id',profile.schoolId)
 ]);
 const now=Date.now();const active=(items??[]).filter((a:any)=>!a.expires_at||new Date(a.expires_at).getTime()>now);const error=params.error==='forbidden'?'النشر متاح للإداريين فقط.':undefined;
 return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}><div className="page-heading"><div><h1>منصة التبليغات</h1><p>آخر أخبار المدرسة والتنبيهات المهمة.</p></div>{profile.role==='admin'&&<Link className="btn primary" href="/announcements/new">+ نشر تبليغ جديد</Link>}</div>{error&&<div className="error">{error}</div>}
 {active.length===0?<div className="card empty-state"><div className="empty-icon">🔔</div><h2>لا توجد تبليغات حالياً</h2><p className="muted">ستظهر التبليغات الجديدة هنا عند نشرها.</p>{profile.role==='admin'&&<Link className="btn primary" href="/announcements/new">نشر أول تبليغ</Link>}</div>:<div className="announcement-list">{active.map((a:any)=>{const p=priority[a.priority]??priority.normal;const read=a.announcement_reads?.some((r:any)=>r.user_id===profile.id);const count=a.announcement_reads?.length??0;return <Link href={`/announcements/${a.id}`} key={a.id} className={`card announcement-card ${read?'':'announcement-unread'}`}><div className="announcement-card-top"><span className={`priority-pill ${p.className}`}><span aria-hidden="true">{p.icon}</span> {p.label}</span><div className="announcement-flags">{a.is_pinned&&<span className="pill">📌 مثبت</span>}{!read&&<span className="pill success">جديد</span>}</div></div><h2>{a.title}</h2><p>{a.body}</p><div className="announcement-meta"><span>{new Date(a.created_at).toLocaleString('ar-IQ',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Baghdad',numberingSystem:'latn'})}</span>{profile.role==='admin'&&<strong>تمت القراءة: {count}</strong>}</div></Link>})}</div>}</AppShell>
}
