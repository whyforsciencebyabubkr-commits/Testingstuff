import { requireFullAdmin } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { AppShell } from '@/components/app-shell';
import SettingsForm from '@/components/settings-form';
export default async function SettingsPage(){const profile=await requireFullAdmin();const supabase=await createSupabaseServer();const {data:school}=await supabase.from('schools').select('name,logo_path,primary_color,timezone,show_rank_total').eq('id',profile.schoolId).maybeSingle();return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}><div className="page-heading"><div><h1>إعدادات المدرسة</h1><p>الاسم واللون والمنطقة الزمنية وإظهار ترتيب «من N».</p></div></div><SettingsForm profile={profile} school={school??{}}/></AppShell>}
