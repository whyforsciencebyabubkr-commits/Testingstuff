import Link from 'next/link';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { AppShell } from '@/components/app-shell';
import { BellIcon, BookIcon, ChartIcon, PlusIcon, UsersIcon } from '@/components/icons';

const dateFormat = (value: string) => new Date(value).toLocaleDateString('ar-IQ', {
  dateStyle: 'medium', timeZone: 'Asia/Baghdad', numberingSystem: 'latn',
});

export default async function Dashboard() {
  const profile = await getCurrentProfile();
  const supabase = await createSupabaseServer();
  const [{ data: school }, { data: classes }] = await Promise.all([
    supabase.from('schools').select('name').eq('id', profile.schoolId).maybeSingle(),
    supabase.from('classes').select('id,grade,section').eq('school_id', profile.schoolId).order('grade'),
  ]);

  const isAdmin = profile.role === 'admin';
  const isTeacher = profile.role === 'teacher';
  const [{ count: students }, { count: teachers }, { count: homeworkCount }, { count: announcements }] = isAdmin
    ? await Promise.all([
      supabase.from('students').select('id', { count: 'exact', head: true }).eq('school_id', profile.schoolId),
      supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('school_id', profile.schoolId).eq('role', 'teacher'),
      supabase.from('homework').select('id', { count: 'exact', head: true }).eq('school_id', profile.schoolId).eq('status', 'active'),
      supabase.from('announcements').select('id', { count: 'exact', head: true }).eq('school_id', profile.schoolId),
    ])
    : [{ count: null }, { count: null }, { count: null }, { count: null }];

  const [{ data: recentHomework }, { data: recentAnnouncements }] = await Promise.all([
    supabase.from('homework').select('id,title,due_at,status,subjects(name)').eq('school_id', profile.schoolId).eq('status', 'active').order('due_at', { ascending: true }).limit(4),
    supabase.from('announcements').select('id,title,priority,created_at,expires_at,is_pinned').eq('school_id', profile.schoolId).order('is_pinned', { ascending: false }).order('created_at', { ascending: false }).limit(4),
  ]);

  let scopedClassCount = classes?.length ?? 0;
  if (isTeacher) {
    const [{ data: classLinks }, { data: studentLinks }] = await Promise.all([
      supabase.from('account_class_links').select('class_id').eq('account_id', profile.id),
      supabase.from('account_student_links').select('student_id,students(class_id)').eq('account_id', profile.id),
    ]);
    const linkedClassIds = new Set([...(classLinks ?? []).map((item) => item.class_id), ...(studentLinks ?? []).map((item: any) => item.students?.class_id).filter(Boolean)]);
    scopedClassCount = (classes ?? []).filter((item) => linkedClassIds.has(item.id)).length;
  }

  const intro = isAdmin
    ? 'نظرة سريعة على المدرسة، مع وصول مباشر إلى مهام الإدارة.'
    : isTeacher
      ? 'مساحة عملك للوصول إلى الواجبات والتقييمات والصفوف المتاحة لك.'
      : 'تابع واجباتك والتبليغات ونتائجك المنشورة من مكان واحد.';

  return <AppShell profile={profile} schoolName={school?.name ?? 'مدرستي'}>
    <div className="page-heading dashboard-heading"><div><span className="eyebrow">{school?.name ?? 'بوابة المدرسة'}</span><h1>مرحباً، {profile.fullName}</h1><p>{intro}</p></div><span className="today-chip">{new Date().toLocaleDateString('ar-IQ', { dateStyle: 'full', timeZone: 'Asia/Baghdad' })}</span></div>

    {isAdmin && <>
      <section aria-label="إحصائيات المدرسة" className="grid stats">
        <Stat icon={<UsersIcon />} label="الطلاب" value={students ?? 0} note="إجمالي الطلاب المسجلين" />
        <Stat icon={<UsersIcon />} label="المعلمون" value={teachers ?? 0} note="حسابات المعلمين" />
        <Stat icon={<BookIcon />} label="الواجبات النشطة" value={homeworkCount ?? 0} note="واجبات غير مؤرشفة" />
        <Stat icon={<BellIcon />} label="التبليغات" value={announcements ?? 0} note="التبليغات في المدرسة" />
      </section>
      <section className="dashboard-section"><div className="section-heading"><div><h2>إدارة المدرسة</h2><p>اختصارات للمهام الإدارية المتكررة.</p></div></div><div className="grid actions">
        <Quick href="/admin/users" icon={<UsersIcon />} title="المستخدمون" desc="إنشاء الحسابات وإدارة المستخدمين" />
        <Quick href="/admin/scope" icon={<UsersIcon />} title="نطاقات الوصول" desc="ربط المعلمين بالصفوف والطلاب" />
        <Quick href="/admin/evaluations" icon={<ChartIcon />} title="إعدادات التقييم" desc="الفصول الدراسية ونشر النتائج" />
      </div></section>
    </>}

    {isTeacher && <section className="dashboard-section"><div className="section-heading"><div><h2>مهام سريعة</h2><p>ابدأ العمل مباشرة من الاختصارات.</p></div></div><div className="grid actions">
      <Quick href="/homework/new" icon={<PlusIcon />} title="نشر واجب" desc="إضافة واجب جديد للطلاب ضمن نطاقك" />
      <Quick href="/evaluations" icon={<ChartIcon />} title="تقييم الطلاب" desc="إدخال الدرجات ومراجعتها" />
      <Quick href="/homework" icon={<BookIcon />} title="متابعة الواجبات" desc="مراجعة الواجبات المنشورة ومواعيدها" />
    </div><div className="card dashboard-note"><UsersIcon /><div><strong>الصفوف المتاحة</strong><p>تعرض الصفحات بيانات الصفوف والطلاب التي تسمح بها صلاحيات حسابك فقط.</p></div><span className="pill">{scopedClassCount} صفوف ضمن نطاقك</span></div></section>}

    {!isTeacher && !isAdmin && <section className="dashboard-section"><div className="section-heading"><div><h2>مساحتك الدراسية</h2><p>افتح الخدمة التي تحتاجها.</p></div></div><div className="grid actions">
      <Quick href="/homework" icon={<BookIcon />} title="واجباتي" desc="المواعيد والواجبات المنشورة لك" />
      <Quick href="/announcements" icon={<BellIcon />} title="التبليغات" desc="آخر الأخبار والتنبيهات المدرسية" />
      <Quick href="/evaluations" icon={<ChartIcon />} title="نتائجي" desc="درجاتك المنشورة حسب الفصل الدراسي" />
      <Quick href="/ranking" icon={<ChartIcon />} title="ترتيبي الدراسي" desc="متوسطك وترتيبك عند إتاحة النتائج" />
    </div></section>}

    <div className="grid dashboard-columns">
      <section className="card dashboard-list"><div className="section-heading"><div><h2>{isTeacher || isAdmin ? 'الواجبات النشطة' : 'الواجبات القادمة'}</h2><p>قائمة مختصرة بأقرب المواعيد.</p></div><Link href="/homework">عرض الكل</Link></div>
        {!recentHomework?.length ? <p className="muted dashboard-empty">لا توجد واجبات نشطة حالياً.</p> : recentHomework.map((item: any) => <Link className="dashboard-row" href={`/homework/${item.id}`} key={item.id}><span className="list-icon"><BookIcon /></span><span className="dashboard-row-copy"><strong>{item.title}</strong><small>{item.subjects?.name ?? 'واجب'} · التسليم {dateFormat(item.due_at)}</small></span><span className="row-arrow">‹</span></Link>)}
      </section>
      <section className="card dashboard-list"><div className="section-heading"><div><h2>التبليغات الأخيرة</h2><p>الإعلانات والتنبيهات المدرسية.</p></div><Link href="/announcements">عرض الكل</Link></div>
        {!recentAnnouncements?.length ? <p className="muted dashboard-empty">لا توجد تبليغات حالياً.</p> : recentAnnouncements.filter((item: any) => !item.expires_at || new Date(item.expires_at).getTime() > Date.now()).map((item: any) => <Link className="dashboard-row" href={`/announcements/${item.id}`} key={item.id}><span className={`list-icon ${item.priority === 'urgent' ? 'urgent' : ''}`}><BellIcon /></span><span className="dashboard-row-copy"><strong>{item.is_pinned ? 'مثبّت · ' : ''}{item.title}</strong><small>{dateFormat(item.created_at)}{item.priority === 'urgent' ? ' · عاجل' : item.priority === 'important' ? ' · مهم' : ''}</small></span><span className="row-arrow">‹</span></Link>)}
      </section>
    </div>
  </AppShell>;
}

function Stat({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: number; note: string }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="icon-box">{icon}</span></div><div className="stat-value">{value.toLocaleString('ar-IQ', { numberingSystem: 'latn' })}</div><p className="stat-note">{note}</p></div>;
}
function Quick({ href, icon, title, desc }: { href: string; icon: React.ReactNode; title: string; desc: string }) {
  return <Link className="card action-card" href={href}><span className="icon-box">{icon}</span><span><strong>{title}</strong><span>{desc}</span></span><span className="action-arrow">‹</span></Link>;
}
