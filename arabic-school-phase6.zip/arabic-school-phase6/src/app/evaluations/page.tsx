import Link from 'next/link';
import { redirect } from 'next/navigation';
import { AppShell } from '@/components/app-shell';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { saveEvaluation, publishResults } from '@/lib/evaluation-actions';

export default async function EvaluationsPage({searchParams}:{searchParams:Promise<{class?:string;subject?:string;period?:string}>}){
 const profile=await getCurrentProfile();const params=await searchParams;const supabase=await createSupabaseServer();
 const [{data:school},{data:periods},{data:subjects},{data:classes}]=await Promise.all([
  supabase.from('schools').select('name,show_rank_total').eq('id',profile.schoolId).maybeSingle(),
  supabase.from('evaluation_periods').select('id,name,max_score,is_active').eq('school_id',profile.schoolId).order('sort_order'),
  supabase.from('subjects').select('id,name').eq('school_id',profile.schoolId).order('name'),
  supabase.from('classes').select('id,grade,section').eq('school_id',profile.schoolId).order('grade')
 ]);
 const periodId=params.period??periods?.find(p=>p.is_active)?.id??periods?.[0]?.id;
 if(profile.role==='student'){
  const {data:student}=await supabase.from('students').select('id,class_id').eq('profile_id',profile.id).maybeSingle();
  const {data:pubs}=student?await supabase.from('evaluation_publications').select('period_id').eq('class_id',student.class_id):{data:[] as {period_id:string}[]};
  const visiblePeriods=(periods??[]).filter(p=>pubs?.some(pub=>pub.period_id===p.id));
  const selected=params.period&&visiblePeriods.some(p=>p.id===params.period)?params.period:visiblePeriods[0]?.id;
  const {data:grades}=student&&selected?await supabase.from('evaluations').select('id,score,teacher_note,subject_id,period_id,subjects(name),evaluation_periods(name,max_score)').eq('student_id',student.id).eq('period_id',selected).order('subject_id'):{data:[] as any[]};
  const {data:rank}=selected?await supabase.rpc('get_my_student_rank',{p_period_id:selected}):{data:[] as any[]};
  return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}><div className="page-heading"><div><h1>نتائجي الدراسية</h1><p>تظهر الدرجات والترتيب بعد نشر النتائج من إدارة المدرسة.</p></div><Link className="btn" href="/ranking">عرض الترتيب</Link></div>
   {visiblePeriods.length>0&&<form className="card toolbar" method="get"><label className="field" style={{margin:0,flex:1}}>الفصل الدراسي<select name="period" defaultValue={selected}><option value="">اختر الفصل</option>{visiblePeriods.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><button className="btn primary">عرض النتائج</button></form>}
   {!visiblePeriods.length?<div className="card empty-state"><div className="empty-icon">📊</div><h2>لم تُنشر النتائج بعد</h2><p className="muted">ستظهر درجاتك هنا فور نشرها للصف من الإدارة.</p></div>:<><div className="grid stats"><div className="stat-card"><div className="stat-top"><span>المواد المنشورة</span></div><div className="stat-value">{grades?.length??0}</div></div>{school?.show_rank_total&&<div className="stat-card"><div className="stat-top"><span>ترتيبك في الصف</span></div><div className="stat-value">{rank?.[0]?.rank??'—'}{rank?.[0]?.total_students?` / ${rank[0].total_students}`:''}</div></div>}</div><div className="card table-wrap"><h2 className="section-title">تفاصيل الدرجات</h2>{!grades?.length?<p className="muted">لا توجد درجات منشورة في هذا الفصل حتى الآن.</p>:<table className="table"><thead><tr><th>المادة</th><th>الدرجة</th><th>النسبة</th><th>ملاحظة المعلم</th></tr></thead><tbody>{grades.map((g:any)=><tr key={g.id}><td>{g.subjects?.name??'—'}</td><td>{g.score} / {g.evaluation_periods?.max_score??'—'}</td><td>{g.evaluation_periods?.max_score?`${(Number(g.score)/Number(g.evaluation_periods.max_score)*100).toFixed(1)}%`:'—'}</td><td>{g.teacher_note||'—'}</td></tr>)}</tbody></table>}</div></>}
  </AppShell>;
 }
 const selectedClass=params.class??classes?.[0]?.id;const selectedSubject=params.subject??subjects?.[0]?.id;
 const visibleClasses=profile.role==='teacher'?[]:(classes??[]);
 let scopedClasses=visibleClasses;
 if(profile.role==='teacher'){const {data:links}=await supabase.from('account_class_links').select('class_id').eq('account_id',profile.id);const {data:studentLinks}=await supabase.from('account_student_links').select('student_id,students(class_id)').eq('account_id',profile.id);const ids=new Set([...(links??[]).map(x=>x.class_id),...(studentLinks??[]).map((x:any)=>x.students?.class_id).filter(Boolean)]);scopedClasses=(classes??[]).filter(c=>ids.has(c.id));}
 const classId=scopedClasses.some(c=>c.id===selectedClass)?selectedClass:scopedClasses[0]?.id;
 const allowedSubjects=profile.role==='teacher'?await supabase.from('teacher_subjects').select('subject_id').eq('teacher_id',profile.id):{data:null};const subjectIds=allowedSubjects.data?.map(x=>x.subject_id);const scopedSubjects=(subjects??[]).filter(s=>!subjectIds||subjectIds.includes(s.id));const subjectId=scopedSubjects.some(s=>s.id===selectedSubject)?selectedSubject:scopedSubjects[0]?.id;
 const activePeriod=(periods??[]).find(p=>p.id===periodId);
 const [{data:students},{data:existing}]=classId&&subjectId&&periodId?await Promise.all([
  supabase.from('students').select('id,profile_id,profiles!students_profile_id_fkey(full_name,username)').eq('school_id',profile.schoolId).eq('class_id',classId),
  supabase.from('evaluations').select('id,student_id,score,teacher_note,teacher_id').eq('school_id',profile.schoolId).eq('subject_id',subjectId).eq('period_id',periodId)
 ]):[{data:[] as any[]},{data:[] as any[]}];
 const gradesByStudent=new Map((existing??[]).map((e:any)=>[e.student_id,e]));
 return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}><div className="page-heading"><div><h1>تقييم الطلاب</h1><p>إدخال الدرجات حسب الصف والمادة والفصل الدراسي.</p></div>{profile.role==='admin'&&profile.adminAccess==='full'&&<Link className="btn" href="/admin/evaluations">إعدادات التقييم</Link>}</div>
 {!periods?.length||!scopedClasses.length||!scopedSubjects.length?<div className="card empty-state"><h2>يلزم إعداد التقييم أولاً</h2><p className="muted">تأكد من إضافة فصل دراسي ومادة وربط المعلم بالصفوف والمواد. يمكن للإدارة ضبط الفصول والتصنيفات من إعدادات التقييم.</p>{profile.role==='admin'&&<Link className="btn primary" href="/admin/evaluations">فتح إعدادات التقييم</Link>}</div>:<><form className="card toolbar" method="get" style={{alignItems:'end'}}><label className="field" style={{margin:0,flex:1}}>الصف<select name="class" defaultValue={classId}>{scopedClasses.map(c=><option key={c.id} value={c.id}>{c.grade} / شعبة {c.section}</option>)}</select></label><label className="field" style={{margin:0,flex:1}}>المادة<select name="subject" defaultValue={subjectId}>{scopedSubjects.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label><label className="field" style={{margin:0,flex:1}}>الفصل الدراسي<select name="period" defaultValue={periodId}>{periods.map(p=><option key={p.id} value={p.id}>{p.name}{p.is_active?'':' (مغلق)'}</option>)}</select></label><button className="btn primary">عرض الطلاب</button></form>
 <div className="card table-wrap"><h2 className="section-title">قائمة الدرجات — الحد الأعلى {activePeriod?.max_score??'—'}</h2>{!students?.length?<p className="muted">لا يوجد طلاب في هذا الصف ضمن نطاقك.</p>:<table className="table"><thead><tr><th>اسم الطالب</th><th>الدرجة</th><th>ملاحظة</th><th>حفظ</th></tr></thead><tbody>{students.map((s:any)=>{const old:any=gradesByStudent.get(s.id);return <tr key={s.id}><td>{s.profiles?.full_name??'طالب'}<div className="muted small">{s.profiles?.username}</div></td><td><form id={`grade-${s.id}`} action={saveEvaluation} className="grade-form"><input type="hidden" name="studentId" value={s.id}/><input type="hidden" name="subjectId" value={subjectId}/><input type="hidden" name="periodId" value={periodId}/><input aria-label="الدرجة" name="score" type="number" min="0" max={activePeriod?.max_score??100} step="0.25" required defaultValue={old?.score??''} style={{width:100,minHeight:40,border:'1px solid var(--border)',borderRadius:9,padding:'0 8px'}}/><input aria-label="ملاحظة المعلم" name="note" maxLength={500} defaultValue={old?.teacher_note??''} placeholder="ملاحظة اختيارية" style={{width:180,minHeight:40,border:'1px solid var(--border)',borderRadius:9,padding:'0 8px',marginInlineStart:8}}/></form></td><td>{old?'مسجلة':'—'}</td><td><button form={`grade-${s.id}`} className="btn primary" type="submit">حفظ الدرجة</button></td></tr>})}</tbody></table>}</div>
 {profile.role==='admin'&&profile.adminAccess==='full'&&<div className="card" style={{marginTop:16}}><h2 className="section-title">نشر النتائج</h2><p className="muted">النشر يجعل نتائج هذا الفصل الدراسي متاحة لطلاب الصف المحدد.</p><form action={publishResults}><input type="hidden" name="classId" value={classId}/><input type="hidden" name="periodId" value={periodId}/><button className="btn primary">نشر نتائج هذا الصف</button></form></div>}</>}
 </AppShell>;
}
