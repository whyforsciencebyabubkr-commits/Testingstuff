import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { AppShell } from '@/components/app-shell';
import { createHomework } from '@/lib/homework-actions';

const errors: Record<string,string> = {
  invalid:'راجع الحقول المطلوبة وتأكد من إدخالها بشكل صحيح.', audience:'اختر صفاً واحداً على الأقل أو طالباً محدداً.',
  scope:'لا يمكنك اختيار صف أو طالب خارج نطاقك.', files:'يمكن إرفاق 5 ملفات كحد أقصى، كل ملف حتى 10 ميغابايت وبصيغة صورة أو PDF.',
  upload:'تعذر رفع المرفقات. تحقق من حجم الملفات ثم حاول مجدداً.', save:'تعذر حفظ الواجب. تحقق من صلاحياتك والمادة المختارة.', forbidden:'لا يملك الطالب صلاحية نشر الواجبات.'
};
export default async function NewHomeworkPage({ searchParams }: {searchParams: Promise<{error?:string}>}) {
  const profile=await getCurrentProfile(); if(profile.role==='student') redirect('/homework');
  const params=await searchParams; const supabase=await createSupabaseServer();
  const [{data:school},{data:classes},{data:students},{data:allSubjects},{data:teacherSubjects}]=await Promise.all([
    supabase.from('schools').select('name').eq('id',profile.schoolId).maybeSingle(),
    supabase.from('classes').select('id,grade,section').eq('school_id',profile.schoolId).order('grade'),
    supabase.from('students').select('id,profile_id,class_id,profiles!students_profile_id_fkey(full_name,username),classes(grade,section)').eq('school_id',profile.schoolId),
    supabase.from('subjects').select('id,name').eq('school_id',profile.schoolId).order('name'),
    profile.role==='teacher' ? supabase.from('teacher_subjects').select('subject_id').eq('teacher_id',profile.id) : Promise.resolve({data:null}),
  ]);
  const allowedIds=profile.role==='teacher'?(teacherSubjects??[]).map((x:any)=>x.subject_id):null;
  const subjects=(allSubjects??[]).filter(s=>!allowedIds||allowedIds.includes(s.id));
  return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}>
    <div className="page-heading"><div><h1>نشر واجب جديد</h1><p>املأ التفاصيل وحدد الطلاب الذين سيصلهم الواجب.</p></div><Link href="/homework" className="btn">رجوع للواجبات</Link></div>
    {params.error && <div className="error">{errors[params.error]??'حدث خطأ غير متوقع.'}</div>}
    <form action={createHomework} className="card homework-form">
      <div className="form-grid">
        <label className="field">عنوان الواجب *<input name="title" required minLength={2} maxLength={160} placeholder="مثال: حل تمارين صفحة 24" /></label>
        <label className="field">المادة *<select name="subjectId" required defaultValue=""><option value="" disabled>اختر المادة</option>{subjects.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
        <label className="field">موعد التسليم *<input name="dueAt" type="datetime-local" required /></label>
        <label className="field">المرفقات (اختياري)<input name="attachments" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple /></label>
        <label className="field form-full">وصف الواجب<textarea name="description" rows={4} maxLength={10000} placeholder="اكتب التعليمات أو تفاصيل الواجب هنا..." /></label>
      </div>
      <div className="audience-section"><h2 className="section-title">تحديد الجمهور *</h2><p className="muted">اختر صفاً أو أكثر، ويمكنك إضافة طلاب محددين أيضاً. لن يقبل النظام أي اختيار خارج نطاق حسابك.</p>
        <h3>الصفوف والشعب</h3><div className="check-grid">{(classes??[]).map(c=><label key={c.id} className="check"><input type="checkbox" name="classIds" value={c.id}/><span>{c.grade} / شعبة {c.section}</span></label>)}</div>
        <h3 style={{marginTop:20}}>طلاب محددون</h3><div className="student-target-list">{(students??[]).map((s:any)=><label key={s.id} className="check"><input type="checkbox" name="studentIds" value={s.id}/><span>{s.profiles?.full_name ?? s.profiles?.username} <small>{s.classes?.grade} / {s.classes?.section}</small></span></label>)}</div>
      </div>
      <div className="muted file-hint">الملفات المسموحة: الصور وPDF فقط، بحد أقصى 5 ملفات، 10 ميغابايت لكل ملف.</div>
      <div className="form-actions toolbar"><button className="btn primary" type="submit">نشر الواجب</button><Link href="/homework" className="btn">إلغاء</Link></div>
    </form>
  </AppShell>;
}
