import Link from 'next/link';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { AppShell } from '@/components/app-shell';

export default async function HomeworkPage({ searchParams }: { searchParams: Promise<{ status?: string; class?: string; subject?: string }> }) {
  const profile = await getCurrentProfile();
  const params = await searchParams;
  const supabase = await createSupabaseServer();
  const [{ data: school }, { data: rows }, { data: subjects }, { data: classes }] = await Promise.all([
    supabase.from('schools').select('name').eq('id', profile.schoolId).maybeSingle(),
    supabase.from('homework').select('id,title,description,due_at,status,created_at,subject_id,publisher_id,subjects(name),profiles!homework_publisher_id_fkey(full_name),homework_class_targets(class_id,classes(grade,section)),homework_student_targets(student_id)').eq('school_id', profile.schoolId).order('due_at', { ascending: true }),
    supabase.from('subjects').select('id,name').eq('school_id', profile.schoolId).order('name'),
    supabase.from('classes').select('id,grade,section').eq('school_id', profile.schoolId).order('grade'),
  ]);
  const filtered = (rows ?? []).filter((row: any) => {
    if (params.status && params.status !== 'all' && row.status !== params.status) return false;
    if (params.class && !row.homework_class_targets?.some((t: any) => t.class_id === params.class)) return false;
    if (params.subject && row.subject_id !== params.subject) return false;
    return true;
  });
  const canPublish = profile.role !== 'student';
  const now = Date.now();
  return <AppShell profile={profile} schoolName={school?.name ?? 'مدرستي'}>
    <div className="page-heading"><div><h1>منصة الواجبات</h1><p>{profile.role === 'student' ? 'واجباتك مرتبة حسب موعد التسليم.' : 'إدارة الواجبات ومتابعة مواعيد التسليم.'}</p></div>{canPublish && <Link className="btn primary" href="/homework/new">+ نشر واجب جديد</Link>}</div>
    {canPublish && <form className="card toolbar" method="get" style={{alignItems:'end'}}>
      <label className="field" style={{margin:0,minWidth:160,flex:1}}>الصف<select name="class" defaultValue={params.class ?? ''}><option value="">كل الصفوف ضمن النطاق</option>{(classes ?? []).map(c=><option key={c.id} value={c.id}>{c.grade} / شعبة {c.section}</option>)}</select></label>
      <label className="field" style={{margin:0,minWidth:160,flex:1}}>المادة<select name="subject" defaultValue={params.subject ?? ''}><option value="">كل المواد</option>{(subjects ?? []).map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
      <label className="field" style={{margin:0,minWidth:140,flex:1}}>الحالة<select name="status" defaultValue={params.status ?? 'active'}><option value="active">نشط</option><option value="archived">مؤرشف</option><option value="all">الكل</option></select></label>
      <button className="btn" type="submit">تطبيق</button>
    </form>}
    {profile.role === 'student' && <div className="toolbar"><Link className="btn" href="/homework?status=active">القادمة</Link><Link className="btn" href="/homework?status=all">الكل</Link></div>}
    {filtered.length === 0 ? <div className="card empty-state"><div className="empty-icon">📚</div><h2>لا توجد واجبات هنا حالياً</h2><p className="muted">عندما تُنشر واجبات ضمن نطاقك ستظهر في هذه الصفحة.</p>{canPublish && <Link className="btn primary" href="/homework/new">نشر أول واجب</Link>}</div> : <div className="grid homework-grid">{filtered.map((item: any) => {
      const due = new Date(item.due_at).getTime(); const expired = due < now; const days = Math.max(0, Math.ceil((due-now)/86400000));
      const targetNames = item.homework_class_targets?.map((t: any)=>`${t.classes?.grade ?? ''} / ${t.classes?.section ?? ''}`).filter(Boolean) ?? [];
      return <Link key={item.id} href={`/homework/${item.id}`} className="card homework-card">
        <div className="homework-card-top"><span className={`pill ${item.status==='archived'?'warning':expired?'warning':'success'}`}>{item.status==='archived'?'مؤرشف':expired?'انتهى موعده':'نشط'}</span><span className="muted small">{item.subjects?.name ?? 'مادة'}</span></div>
        <h2>{item.title}</h2><p className="muted homework-desc">{item.description || 'لا يوجد وصف إضافي لهذا الواجب.'}</p>
        <div className="homework-meta"><span>◷ موعد التسليم</span><strong>{new Date(item.due_at).toLocaleString('ar-IQ',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Baghdad', numberingSystem:'latn'})}</strong></div>
        {profile.role==='student' ? <div className="due-countdown">{expired?'متأخر':days===0?'التسليم اليوم':days===1?'غداً':`باقي ${days} أيام`}</div> : <div className="homework-meta"><span>الجمهور</span><strong>{targetNames.length ? targetNames.join('، ') : 'طلاب محددون'}</strong></div>}
      </Link>;
    })}</div>}
  </AppShell>;
}
