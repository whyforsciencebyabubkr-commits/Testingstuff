import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
import { AppShell } from '@/components/app-shell';
import { duplicateHomeworkToClass, editHomework, updateHomeworkStatus } from '@/lib/homework-actions';
import { ConfirmDeleteHomework } from '@/components/confirm-delete-homework';

export default async function HomeworkDetail({params,searchParams}:{params:Promise<{id:string}>;searchParams:Promise<{error?:string;created?:string;saved?:string}>}) {
 const profile=await getCurrentProfile(); const {id}=await params; const query=await searchParams; const supabase=await createSupabaseServer();
 const [{data:school},{data:item},{data:subjects},{data:classes},{data:attachments}]=await Promise.all([
  supabase.from('schools').select('name').eq('id',profile.schoolId).maybeSingle(),
  supabase.from('homework').select('*,subjects(name),profiles!homework_publisher_id_fkey(full_name),homework_class_targets(class_id,classes(grade,section)),homework_student_targets(student_id)').eq('id',id).maybeSingle(),
  supabase.from('subjects').select('id,name').eq('school_id',profile.schoolId).order('name'),
  supabase.from('classes').select('id,grade,section').eq('school_id',profile.schoolId).order('grade'),
  supabase.from('homework_attachments').select('id,file_name,storage_path,mime_type,size_bytes').eq('homework_id',id),
 ]);
 if(!item) notFound();
 const canManage=profile.role!=='student'&&((profile.role==='admin'&&profile.adminAccess==='full')||item.publisher_id===profile.id);
 const signedFiles=[];
 if(attachments?.length) for(const file of attachments){const {data}=await supabase.storage.from('homework-files').createSignedUrl(file.storage_path,60*5);if(data?.signedUrl)signedFiles.push({...file,url:data.signedUrl});}
 const dateInput=new Date(item.due_at).toISOString().slice(0,16);
 const errorText=query.error==='scope'?'لا يمكنك استهداف صف خارج نطاقك.':query.error==='permission'?'لا تملك صلاحية تعديل هذا الواجب.':query.error==='invalid'?'راجع الحقول المطلوبة.':undefined;
 return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}>
  <div className="page-heading"><div><h1>{item.title}</h1><p>{item.subjects?.name??'واجب'} · نشره {item.profiles?.full_name??'المعلم'}</p></div><Link className="btn" href="/homework">رجوع للواجبات</Link></div>
  {query.created&&<div className="success">تم نشر الواجب بنجاح.</div>}{query.saved&&<div className="success">تم حفظ التعديلات.</div>}{errorText&&<div className="error">{errorText}</div>}
  <section className="card homework-detail"><div className="homework-card-top"><span className={`pill ${item.status==='active'?'success':'warning'}`}>{item.status==='active'?'نشط':'مؤرشف'}</span><span className="muted">{new Date(item.created_at).toLocaleDateString('ar-IQ',{dateStyle:'medium',timeZone:'Asia/Baghdad',numberingSystem:'latn'})}</span></div>
   <h2>تعليمات الواجب</h2><p className="detail-description">{item.description||'لا توجد تعليمات إضافية.'}</p>
   <div className="detail-due"><span>موعد التسليم</span><strong>{new Date(item.due_at).toLocaleString('ar-IQ',{dateStyle:'full',timeStyle:'short',timeZone:'Asia/Baghdad',numberingSystem:'latn'})}</strong></div>
   <h2>الفصول المستهدفة</h2><div className="target-chips">{(item.homework_class_targets??[]).map((t:any)=><span className="pill" key={t.class_id}>{t.classes?.grade} / شعبة {t.classes?.section}</span>)}{(item.homework_student_targets??[]).length>0&&<span className="pill">طلاب محددون: {(item.homework_student_targets??[]).length}</span>}</div>
   <h2>المرفقات</h2>{signedFiles.length===0?<p className="muted">لا توجد مرفقات.</p>:<div className="attachment-list">{signedFiles.map(file=><a className="attachment-row" key={file.id} href={file.url} target="_blank" rel="noreferrer"><span>📎 {file.file_name}</span><span className="muted">{(file.size_bytes/1024/1024).toFixed(2)} MB · فتح الملف ↗</span></a>)}</div>}
  </section>
  {canManage&&<>
   <section className="card admin-homework-panel"><h2 className="section-title">تعديل الواجب</h2><form action={editHomework} className="form-grid"><input type="hidden" name="homeworkId" value={item.id}/><label className="field">عنوان الواجب<input name="title" required defaultValue={item.title}/></label><label className="field">المادة<select name="subjectId" defaultValue={item.subject_id}>{(subjects??[]).map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label><label className="field">موعد التسليم<input type="datetime-local" name="dueAt" required defaultValue={dateInput}/></label><label className="field form-full">الوصف<textarea name="description" rows={3} defaultValue={item.description}/></label><div className="form-actions"><button className="btn primary" type="submit">حفظ التعديلات</button></div></form>
   <div className="toolbar" style={{marginTop:16}}><form action={updateHomeworkStatus}><input type="hidden" name="homeworkId" value={item.id}/><input type="hidden" name="status" value={item.status==='active'?'archived':'active'}/><button className="btn" type="submit">{item.status==='active'?'أرشفة الواجب':'إعادة تفعيل الواجب'}</button></form><ConfirmDeleteHomework homeworkId={item.id}/></div>
   <h2 className="section-title" style={{marginTop:22}}>نسخ الواجب إلى صف آخر</h2><form action={duplicateHomeworkToClass} className="toolbar"><input type="hidden" name="homeworkId" value={item.id}/><select name="classId" required defaultValue=""><option value="" disabled>اختر الصف</option>{(classes??[]).map(c=><option key={c.id} value={c.id}>{c.grade} / شعبة {c.section}</option>)}</select><button className="btn" type="submit">إنشاء نسخة</button></form>
   </section>
  </>}
 </AppShell>;
}
