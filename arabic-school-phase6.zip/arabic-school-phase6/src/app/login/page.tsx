'use client';
import { useActionState } from 'react';
import { login } from '@/lib/auth-actions';

const demos=[['mainadmin','إداري'],['adminrestricted','إداري مقيد'],['teacher_a','معلم'],['teacher_b','معلم'],['teacher_c','معلم'],['student01','طالب']];
const initial={error:''};
export default function LoginPage(){
 const [state,action,pending]=useActionState(login,initial);
 return <main className="login-page"><div className="login-wrap">
   <div className="login-brand"><div className="brand-logo">ن</div><h1>نظام إدارة المدارس</h1><p className="muted">منصة مدرسية عربية بسيطة وآمنة</p></div>
   <section className="card login-card"><h2>تسجيل الدخول</h2><p className="muted">اختر صفتك ثم أدخل بيانات الحساب.</p>
    <form action={action}>
      <div className="field"><label htmlFor="role">الدخول كـ</label><select id="role" name="selectedRole" defaultValue="student"><option value="admin">إداري</option><option value="teacher">معلم</option><option value="student">طالب</option></select></div>
      <div className="field"><label htmlFor="username">اسم المستخدم</label><input id="username" name="username" autoComplete="username" placeholder="مثال: teacher_a" required/></div>
      <div className="field"><label htmlFor="password">كلمة المرور</label><input id="password" name="password" type="password" autoComplete="current-password" required/></div>
      {state?.error && <div className="error" role="alert">{state.error}</div>}
      <button className="primary-btn" type="submit" disabled={pending}>{pending?'جارٍ الدخول…':'دخول'}</button>
    </form>
    {process.env.NEXT_PUBLIC_SHOW_DEMO_LOGINS === 'true' && <div className="demo"><strong>حسابات العرض</strong><div className="demo-grid">{demos.map(([u,r])=><div className="demo-row" key={u}><span>{u}</span><span className="muted">{r}</span></div>)}</div><p className="muted">كلمة المرور التجريبية تختلف حسب الحساب؛ راجع seed.sql.</p></div>}
   </section>
 </div></main>
}
