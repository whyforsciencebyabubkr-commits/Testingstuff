import type { Metadata } from 'next';
import './globals.css';
import { PwaRegister } from '@/components/pwa-register';

export const metadata: Metadata = {
  title: 'نظام إدارة المدارس',
  description: 'منصة مدرسية عربية لإدارة الواجبات والتبليغات والتقييم',
  applicationName: 'نظام إدارة المدارس',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'مدرستي' },
  icons: { icon: [{ url: '/icons/icon-192.png', type: 'image/png' }, { url: '/icons/icon-192.svg', type: 'image/svg+xml' }], apple: [{ url: '/icons/apple-touch-icon.png', type: 'image/png' }] },
  formatDetection: { telephone: false },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body><PwaRegister />{children}</body></html>;
}
