import Link from 'next/link';
import { redirect } from 'next/navigation';
import { AppShell } from '@/components/app-shell';
import { getCurrentProfile } from '@/lib/auth';
import { createSupabaseServer } from '@/lib/supabase-server';
export default async function RankingPage({searchParams}:{searchParams:Promise<{period?:string}>}){
 const profile=await getCurrentProfile();if(profile.role!=='student')redirect('/evaluations');const params=await searchParams;const supabase=await createSupabaseServer();
 const [{data:school},{data:student},{data:periods}]=await Promise.all([
  supabase.from('schools').select('name,show_rank_total').eq('id',profile.schoolId).maybeSingle(),
  supabase.from('students').select('id,class_id').eq('profile_id',profile.id).maybeSingle(),
  supabase.from('evaluation_periods').select('id,name').eq('school_id',profile.schoolId).order('sort_order')
 ]);
 const {data:publications}=student?await supabase.from('evaluation_publications').select('period_id').eq('class_id',student.class_id):{data:[] as {period_id:string}[]};
 const available=(periods??[]).filter(p=>publications?.some(x=>x.period_id===p.id));const selected=params.period&&available.some(p=>p.id===params.period)?params.period:available[0]?.id;
 const {data:rank}=selected?await supabase.rpc('get_my_student_rank',{p_period_id:selected}):{data:[] as any[]};
 const {data:thresholds}=await supabase.from('evaluation_thresholds').select('label,min_score,sort_order').eq('school_id',profile.schoolId).order('sort_order');
 const pct=rank?.[0]?.average_percentage==null?null:Number(rank[0].average_percentage);const rating=pct===null?null:(thresholds??[]).find((t,i)=>pct>=Number(t.min_score)&&(!(thresholds??[])[i-1]||pct<Number((thresholds??[])[i-1].min_score)))?.label??null;
 return <AppShell profile={profile} schoolName={school?.name??'مدرستي'}><div className="page-heading"><div><h1>الترتيب الدراسي</h1><p>عرض خاص بك فقط، ولا تظهر أسماء أو درجات بقية الطلاب.</p></div><Link className="btn" href="/evaluations">تفاصيل درجاتي</Link></div>
 {!available.length?<div className="card empty-state"><div className="empty-icon">🏅</div><h2>الترتيب غير متاح بعد</h2><p className="muted">يظهر ترتيب الصف بعد نشر النتائج من الإدارة.</p></div>:<><form className="card toolbar" method="get"><label className="field" style={{margin:0,flex:1}}>الفصل الدراسي<select name="period" defaultValue={selected}>{available.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><button className="btn primary">عرض الترتيب</button></form><div className="grid stats"><div className="stat-card"><div className="stat-top"><span>ترتيبك في الصف</span><span className="icon-box">🏅</span></div><div className="stat-value">{rank?.[0]?.rank??'—'}{school?.show_rank_total&&rank?.[0]?.total_students?` / ${rank[0].total_students}`:''}</div></div><div className="stat-card"><div className="stat-top"><span>متوسط النسبة المنشورة</span><span className="icon-box">%</span></div><div className="stat-value">{pct===null?'—':`${pct.toFixed(2)}%`}</div></div><div className="stat-card"><div className="stat-top"><span>التقدير</span><span className="icon-box">✦</span></div><div className="stat-value" style={{fontSize:22}}>{rating??(pct===null?'—':'غير محدد')}</div></div></div><div className="card" style={{marginTop:16}}><h2 className="section-title">كيف يُحسب الترتيب؟</h2><p className="muted">يُحسب متوسط النسبة المئوية للدرجات المسجلة في الفصل الدراسي المنشور، ويُستخدم الترتيب التنافسي عند تساوي المتوسطات. لا تُعرض قائمة ترتيب عامة حفاظاً على خصوصية الطلاب.</p></div></>}
 </AppShell>;
}
