export type AppRole = 'admin' | 'teacher' | 'student';
export type AdminAccess = 'full' | 'restricted';

export type CurrentProfile = {
  id: string;
  schoolId: string;
  role: AppRole;
  username: string;
  fullName: string;
  isActive: boolean;
  mustChangePassword: boolean;
  adminAccess: AdminAccess | null;
};
