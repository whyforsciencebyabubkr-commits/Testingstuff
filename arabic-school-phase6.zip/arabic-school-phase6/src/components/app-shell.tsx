import Link from 'next/link';
import { logout } from '@/lib/auth-actions';
import type { CurrentProfile } from '@/types/auth';
import { BellIcon, BookIcon, ChartIcon, HomeIcon, LogOutIcon, MenuIcon, SettingsIcon, UsersIcon, LinkIcon } from './icons';
import { createSupabaseServer } from '@/lib/supabase-server';

const items = [
  { href: '/dashboard', label: 'الرئيسية', icon: HomeIcon },
  { href: '/homework', label: 'الواجبات', icon: BookIcon },
  { href: '/announcements', label: 'التبليغات', icon: BellIcon, badge: true },
  { href: '/evaluations', label: 'التقييم', icon: ChartIcon },
];

export async function AppShell({ profile, schoolName, children }: { profile: CurrentProfile; schoolName: string; children: React.ReactNode }) {
  const isAdmin = profile.role === 'admin';
  const supabase = await createSupabaseServer();
  const { data: visibleAnnouncements } = await supabase.from('announcements').select('id,expires_at').eq('school_id', profile.schoolId);
  const now = Date.now();
  const announcementIds = (visibleAnnouncements ?? []).filter((a) => !a.expires_at || new Date(a.expires_at).getTime() > now).map((a) => a.id);
  const { data: readRows } = announcementIds.length ? await supabase.from('announcement_reads').select('announcement_id').eq('user_id', profile.id).in('announcement_id', announcementIds) : { data: [] as { announcement_id: string }[] };
  const unreadCount = Math.max(0, announcementIds.length - (readRows?.length ?? 0));
  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-logo">ن</div><div className="brand-name">{schoolName}</div></div>
      <div className="top-actions">
        <div className="user-chip"><div className="avatar">{profile.fullName.slice(0,1)}</div><div className="user-copy"><strong>{profile.fullName}</strong><span className="role">{profile.role === 'admin' ? 'إداري' : profile.role === 'teacher' ? 'معلم' : 'طالب'}</span></div></div>
        <div className="menu"><details><summary aria-label="القائمة"><MenuIcon /></summary><div className="menu-pop">
          {isAdmin && <Link href="/admin"><SettingsIcon size={18}/> لوحة الإدارة</Link>}
          <form action={logout}><button type="submit"><LogOutIcon size={18}/> تسجيل الخروج</button></form>
        </div></details></div>
      </div>
    </header>
    <div className="layout">
      <aside className="sidebar"><nav className="nav-list">{items.map(({ href,label,icon:Icon,badge })=><Link key={label} href={href} className="nav-item"><Icon size={20}/>{label}{badge && unreadCount > 0 && <span className="nav-badge">{unreadCount > 99 ? '99+' : unreadCount}</span>}</Link>)}{isAdmin && <><Link href="/admin/evaluations" className="nav-item"><ChartIcon size={20}/>إعدادات التقييم</Link><Link href="/admin/users" className="nav-item"><UsersIcon size={20}/>المستخدمون</Link><Link href="/admin/scope" className="nav-item"><LinkIcon size={20}/>ربط الحسابات</Link></>}</nav></aside>
      <main className="main">{children}</main>
    </div>
    <nav className="mobile-nav">{items.map(({ href,label,icon:Icon,badge })=><Link key={label} href={href}><Icon size={20}/>{label}{badge && unreadCount > 0 && <span className="nav-badge">{unreadCount > 99 ? '99+' : unreadCount}</span>}</Link>)}</nav>
  </div>;
}
