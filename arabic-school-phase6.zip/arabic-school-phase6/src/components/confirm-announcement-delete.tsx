'use client';
export function ConfirmAnnouncementDelete(){return <button className="btn danger" type="submit" onClick={(event)=>{if(!window.confirm('هل أنت متأكد من حذف هذا التبليغ؟'))event.preventDefault();}}>حذف التبليغ</button>}
