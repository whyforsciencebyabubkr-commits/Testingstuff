'use client';
import { deleteHomework } from '@/lib/homework-actions';
export function ConfirmDeleteHomework({ homeworkId }: { homeworkId: string }) {
  return <form action={deleteHomework} onSubmit={(event) => { if (!window.confirm('هل أنت متأكد من حذف هذا الواجب؟ لا يمكن التراجع عن الحذف.')) event.preventDefault(); }}>
    <input type="hidden" name="homeworkId" value={homeworkId}/><button className="btn danger" type="submit">حذف الواجب</button>
  </form>;
}
