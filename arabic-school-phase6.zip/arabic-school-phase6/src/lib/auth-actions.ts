'use server';

import { redirect } from 'next/navigation';
import { z } from 'zod';
import { createSupabaseServer } from './supabase-server';

const loginSchema = z.object({
  username: z.string().trim().min(1).max(80),
  password: z.string().min(1).max(200),
  selectedRole: z.enum(['admin', 'teacher', 'student']),
});

const roleNames = { admin: 'إداري', teacher: 'معلم', student: 'طالب' } as const;

export async function login(formData: FormData) {
  const parsed = loginSchema.safeParse({
    username: formData.get('username'),
    password: formData.get('password'),
    selectedRole: formData.get('selectedRole'),
  });
  if (!parsed.success) return { error: 'يرجى إدخال اسم المستخدم وكلمة المرور.' };

  const supabase = await createSupabaseServer();
  const authEmail = `${parsed.data.username}@demo.local`;
  const { error: authError } = await supabase.auth.signInWithPassword({
    email: authEmail,
    password: parsed.data.password,
  });
  if (authError) return { error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' };

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('id, role, is_active, must_change_password')
    .eq('username', parsed.data.username)
    .maybeSingle();

  if (profileError || !profile || !profile.is_active) {
    await supabase.auth.signOut();
    return { error: 'هذا الحساب غير متاح حاليًا.' };
  }

  if (profile.role !== parsed.data.selectedRole) {
    await supabase.auth.signOut();
    return { error: `هذا الحساب غير مسجّل بهذه الصفة. اختر «${roleNames[profile.role]}».` };
  }

  if (profile.must_change_password) redirect('/change-password');
  redirect('/dashboard');
}

export async function logout() {
  const supabase = await createSupabaseServer();
  await supabase.auth.signOut();
  redirect('/login');
}

export async function changePassword(formData: FormData) {
  const password = String(formData.get('password') ?? '');
  const confirm = String(formData.get('confirm') ?? '');
  if (password.length < 8) return { error: 'كلمة المرور يجب أن تكون 8 أحرف أو أكثر.' };
  if (password !== confirm) return { error: 'كلمتا المرور غير متطابقتين.' };

  const supabase = await createSupabaseServer();
  const { data: user } = await supabase.auth.getUser();
  if (!user.user) redirect('/login');

  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: 'تعذر تغيير كلمة المرور. حاول مرة أخرى.' };
  const { error: profileError } = await supabase
    .from('profiles')
    .update({ must_change_password: false })
    .eq('id', user.user.id);
  if (profileError) return { error: 'تم تغيير كلمة المرور لكن تعذر تحديث حالة الحساب.' };
  redirect('/dashboard');
}
