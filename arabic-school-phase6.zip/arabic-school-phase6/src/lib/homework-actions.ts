'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { getCurrentProfile } from './auth';
import { createSupabaseServer } from './supabase-server';

const schema = z.object({
  title: z.string().trim().min(2, 'اكتب عنواناً واضحاً للواجب').max(160),
  subjectId: z.string().uuid('اختر المادة'),
  description: z.string().trim().max(10000).default(''),
  dueAt: z.string().min(1, 'حدد موعد التسليم'),
});
const MAX_FILE = 10 * 1024 * 1024;
const ALLOWED = new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf']);

export async function createHomework(formData: FormData) {
  const profile = await getCurrentProfile();
  if (profile.role === 'student') redirect('/homework?error=forbidden');
  const supabase = await createSupabaseServer();
  const parsed = schema.safeParse({
    title: formData.get('title'), subjectId: formData.get('subjectId'),
    description: formData.get('description') ?? '', dueAt: formData.get('dueAt'),
  });
  if (!parsed.success) redirect('/homework/new?error=invalid');

  const classIds = [...new Set(formData.getAll('classIds').filter((v): v is string => typeof v === 'string'))];
  const studentIds = [...new Set(formData.getAll('studentIds').filter((v): v is string => typeof v === 'string'))];
  if (!classIds.length && !studentIds.length) redirect('/homework/new?error=audience');

  const [{ data: classRows }, { data: studentRows }, { data: subject }] = await Promise.all([
    classIds.length ? supabase.from('classes').select('id').in('id', classIds) : Promise.resolve({ data: [] as {id:string}[] }),
    studentIds.length ? supabase.from('students').select('id').in('id', studentIds) : Promise.resolve({ data: [] as {id:string}[] }),
    supabase.from('subjects').select('id').eq('id', parsed.data.subjectId).maybeSingle(),
  ]);
  if (!subject || (classRows?.length ?? 0) !== classIds.length || (studentRows?.length ?? 0) !== studentIds.length) redirect('/homework/new?error=scope');

  const { data: homework, error } = await supabase.from('homework').insert({
    school_id: profile.schoolId, publisher_id: profile.id, title: parsed.data.title,
    subject_id: parsed.data.subjectId, description: parsed.data.description,
    due_at: new Date(parsed.data.dueAt).toISOString(), status: 'active',
  }).select('id').single();
  if (error || !homework) redirect('/homework/new?error=save');

  if (classIds.length) {
    const { error: targetError } = await supabase.from('homework_class_targets').insert(classIds.map(class_id => ({ homework_id: homework.id, class_id })));
    if (targetError) { await supabase.from('homework').delete().eq('id', homework.id); redirect('/homework/new?error=scope'); }
  }
  if (studentIds.length) {
    const { error: targetError } = await supabase.from('homework_student_targets').insert(studentIds.map(student_id => ({ homework_id: homework.id, student_id })));
    if (targetError) { await supabase.from('homework').delete().eq('id', homework.id); redirect('/homework/new?error=scope'); }
  }

  const files = formData.getAll('attachments').filter((f): f is File => f instanceof File && f.size > 0);
  if (files.length > 5 || files.some(f => f.size > MAX_FILE || !ALLOWED.has(f.type))) {
    await supabase.from('homework').delete().eq('id', homework.id);
    redirect('/homework/new?error=files');
  }
  for (const file of files) {
    const safeName = file.name.replace(/[^\p{L}\p{N}._-]/gu, '_').slice(-120) || 'attachment';
    const path = `${profile.schoolId}/${homework.id}/${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from('homework-files').upload(path, file, { contentType: file.type, upsert: false });
    if (uploadError) {
      await supabase.from('homework').delete().eq('id', homework.id);
      redirect('/homework/new?error=upload');
    }
    const { error: metaError } = await supabase.from('homework_attachments').insert({
      school_id: profile.schoolId, homework_id: homework.id, uploaded_by: profile.id,
      storage_path: path, file_name: safeName, mime_type: file.type, size_bytes: file.size,
    });
    if (metaError) {
      await supabase.storage.from('homework-files').remove([path]);
      await supabase.from('homework').delete().eq('id', homework.id);
      redirect('/homework/new?error=upload');
    }
  }
  await supabase.rpc('audit_event', { p_action: 'create', p_table: 'homework', p_record: homework.id, p_metadata: { attachment_count: files.length } });
  revalidatePath('/homework');
  revalidatePath('/dashboard');
  redirect(`/homework/${homework.id}?created=1`);
}

export async function updateHomeworkStatus(formData: FormData) {
  const profile = await getCurrentProfile();
  if (profile.role === 'student') redirect('/homework');
  const id = String(formData.get('homeworkId') ?? '');
  const status = String(formData.get('status') ?? '');
  if (!/^[0-9a-f-]{36}$/i.test(id) || !['active', 'archived'].includes(status)) redirect('/homework');
  const supabase = await createSupabaseServer();
  const { error } = await supabase.from('homework').update({ status }).eq('id', id);
  if (error) redirect(`/homework/${id}?error=permission`);
  await supabase.rpc('audit_event', { p_action: status === 'archived' ? 'archive' : 'restore', p_table: 'homework', p_record: id });
  revalidatePath('/homework'); revalidatePath(`/homework/${id}`); redirect('/homework');
}

export async function deleteHomework(formData: FormData) {
  const profile = await getCurrentProfile();
  if (profile.role === 'student') redirect('/homework');
  const id = String(formData.get('homeworkId') ?? '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) redirect('/homework');
  const supabase = await createSupabaseServer();
  const { data: files } = await supabase.from('homework_attachments').select('storage_path').eq('homework_id', id);
  if (files?.length) await supabase.storage.from('homework-files').remove(files.map(f => f.storage_path));
  const { error } = await supabase.from('homework').delete().eq('id', id);
  if (error) redirect(`/homework/${id}?error=permission`);
  await supabase.rpc('audit_event', { p_action: 'delete', p_table: 'homework', p_record: id });
  revalidatePath('/homework'); redirect('/homework');
}

export async function editHomework(formData: FormData) {
  const profile = await getCurrentProfile();
  if (profile.role === 'student') redirect('/homework');
  const id = String(formData.get('homeworkId') ?? '');
  const parsed = schema.safeParse({ title: formData.get('title'), subjectId: formData.get('subjectId'), description: formData.get('description') ?? '', dueAt: formData.get('dueAt') });
  if (!/^[0-9a-f-]{36}$/i.test(id) || !parsed.success) redirect(`/homework/${id}?error=invalid`);
  const supabase = await createSupabaseServer();
  const { error } = await supabase.from('homework').update({ title: parsed.data.title, subject_id: parsed.data.subjectId, description: parsed.data.description, due_at: new Date(parsed.data.dueAt).toISOString() }).eq('id', id);
  if (error) redirect(`/homework/${id}?error=permission`);
  await supabase.rpc('audit_event', { p_action: 'update', p_table: 'homework', p_record: id });
  revalidatePath('/homework'); revalidatePath(`/homework/${id}`); redirect(`/homework/${id}?saved=1`);
}

export async function duplicateHomeworkToClass(formData: FormData) {
  const profile = await getCurrentProfile();
  if (profile.role === 'student') redirect('/homework');
  const id = String(formData.get('homeworkId') ?? '');
  const classId = String(formData.get('classId') ?? '');
  const supabase = await createSupabaseServer();
  const { data: original } = await supabase.from('homework').select('id,title,subject_id,description,due_at,status,school_id').eq('id', id).maybeSingle();
  if (!original || !/^[0-9a-f-]{36}$/i.test(classId)) redirect('/homework');
  const { data: copy, error } = await supabase.from('homework').insert({ school_id: original.school_id, publisher_id: profile.id, title: `${original.title} (نسخة)`, subject_id: original.subject_id, description: original.description, due_at: original.due_at, status: 'active' }).select('id').single();
  if (error || !copy) redirect(`/homework/${id}?error=permission`);
  const { error: targetError } = await supabase.from('homework_class_targets').insert({ homework_id: copy.id, class_id: classId });
  if (targetError) { await supabase.from('homework').delete().eq('id', copy.id); redirect(`/homework/${id}?error=scope`); }
  await supabase.rpc('audit_event', { p_action: 'duplicate', p_table: 'homework', p_record: copy.id, p_metadata: { source_id: id, class_id: classId } });
  revalidatePath('/homework'); redirect(`/homework/${copy.id}`);
}
