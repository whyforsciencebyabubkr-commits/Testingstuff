'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { createSupabaseAdmin } from './supabase-admin';
import { createSupabaseServer } from './supabase-server';
import { requireFullAdmin } from './auth';

const accountSchema = z.object({
  role: z.enum(['admin', 'teacher', 'student']),
  adminAccess: z.enum(['full', 'restricted']).nullable(),
  username: z.string().trim().min(3).max(60).regex(/^[A-Za-z0-9_]+$/),
  fullName: z.string().trim().min(2).max(120),
  password: z.string().min(8).max(200),
  classId: z.string().uuid().nullable(),
});

export async function createAccount(formData: FormData) {
  const actor = await requireFullAdmin();
  const parsed = accountSchema.safeParse({
    role: formData.get('role'),
    adminAccess: formData.get('role') === 'admin' ? formData.get('adminAccess') : null,
    username: formData.get('username'),
    fullName: formData.get('fullName'),
    password: formData.get('password'),
    classId: formData.get('classId') || null,
  });
  if (!parsed.success) return { error: 'تحقق من البيانات المدخلة. اسم المستخدم بالإنجليزية والأرقام وشرطة سفلية فقط.' };
  if (parsed.data.role === 'student' && !parsed.data.classId) return { error: 'اختر صف الطالب.' };

  const admin = createSupabaseAdmin();
  const email = `${parsed.data.username}@demo.local`;
  const { data: created, error } = await admin.auth.admin.createUser({
    email,
    password: parsed.data.password,
    email_confirm: true,
    user_metadata: { username: parsed.data.username },
  });
  if (error || !created.user) return { error: error?.message?.includes('already') ? 'اسم المستخدم مستخدم مسبقًا.' : 'تعذر إنشاء الحساب.' };

  const { error: profileError } = await admin.from('profiles').insert({
    id: created.user.id,
    school_id: actor.schoolId,
    role: parsed.data.role,
    admin_access: parsed.data.role === 'admin' ? parsed.data.adminAccess : null,
    username: parsed.data.username,
    full_name: parsed.data.fullName,
    auth_email: email,
    must_change_password: true,
  });
  if (profileError) {
    await admin.auth.admin.deleteUser(created.user.id);
    return { error: 'تعذر حفظ بيانات الحساب.' };
  }

  if (parsed.data.role === 'student') {
    const { error: studentError } = await admin.from('students').insert({
      profile_id: created.user.id,
      school_id: actor.schoolId,
      class_id: parsed.data.classId,
    });
    if (studentError) { await admin.from('profiles').delete().eq('id', created.user.id); await admin.auth.admin.deleteUser(created.user.id); return { error: 'تعذر ربط الطالب بالصف، ولم يتم إنشاء الحساب.' }; }
  }

  await admin.from('audit_logs').insert({ school_id: actor.schoolId, actor_id: actor.id, action: 'create', table_name: 'profiles', record_id: created.user.id, metadata: { username: parsed.data.username, role: parsed.data.role } });
  revalidatePath('/admin/users');
  return { success: 'تم إنشاء الحساب بنجاح.' };
}

export async function toggleAccount(formData: FormData) {
  const actor = await requireFullAdmin();
  const id = String(formData.get('id') ?? '');
  const active = formData.get('active') === 'true';
  const admin = createSupabaseAdmin();
  const { data: target } = await admin.from('profiles').select('id, username, role, admin_access').eq('id', id).maybeSingle();
  if (!target || target.id === actor.id || (target.username === 'mainadmin' && !active)) return { error: 'لا يمكن تعطيل هذا الحساب.' };
  const { error } = await admin.from('profiles').update({ is_active: active }).eq('id', id);
  if (error) return { error: 'تعذر تحديث حالة الحساب.' };
  await admin.from('audit_logs').insert({ school_id: actor.schoolId, actor_id: actor.id, action: active ? 'activate' : 'deactivate', table_name: 'profiles', record_id: id, metadata: {} });
  revalidatePath('/admin/users');
  return { success: active ? 'تم تفعيل الحساب.' : 'تم تعطيل الحساب.' };
}

export async function resetPassword(formData: FormData) {
  const actor = await requireFullAdmin();
  const id = String(formData.get('id') ?? '');
  const password = String(formData.get('password') ?? '');
  if (password.length < 8) return { error: 'كلمة المرور المؤقتة يجب أن تكون 8 أحرف أو أكثر.' };
  const admin = createSupabaseAdmin();
  const { error } = await admin.auth.admin.updateUserById(id, { password });
  if (error) return { error: 'تعذر إعادة تعيين كلمة المرور.' };
  const { error: profileError } = await admin.from('profiles').update({ must_change_password: true }).eq('id', id);
  if (profileError) return { error: 'تم تغيير كلمة المرور لكن تعذر تفعيل طلب التغيير الأول.' };
  await admin.from('audit_logs').insert({ school_id: actor.schoolId, actor_id: actor.id, action: 'reset_password', table_name: 'profiles', record_id: id, metadata: {} });
  revalidatePath('/admin/users');
  return { success: 'تم تعيين كلمة مرور مؤقتة جديدة.' };
}


export async function updateSchoolSettings(formData: FormData) {
  const actor = await requireFullAdmin();
  const name = String(formData.get('name') ?? '').trim();
  const timezone = String(formData.get('timezone') ?? '').trim();
  const primaryColor = String(formData.get('primaryColor') ?? '').trim();
  const showRankTotal = formData.get('showRankTotal') === 'yes';
  if (name.length < 2 || name.length > 160) return { error: 'اسم المدرسة غير صالح.' };
  if (!/^#[0-9a-fA-F]{6}$/.test(primaryColor)) return { error: 'اللون الأساسي يجب أن يكون بصيغة #RRGGBB.' };
  const admin = createSupabaseAdmin();
  const { error } = await admin.from('schools').update({ name, timezone, primary_color: primaryColor, show_rank_total: showRankTotal }).eq('id', actor.schoolId);
  if (error) return { error: 'تعذر حفظ إعدادات المدرسة.' };
  await admin.from('audit_logs').insert({ school_id: actor.schoolId, actor_id: actor.id, action: 'update', table_name: 'schools', record_id: actor.schoolId, metadata: { name, timezone, primaryColor, showRankTotal } });
  revalidatePath('/admin');
  revalidatePath('/admin/settings');
  revalidatePath('/dashboard');
  return { success: 'تم حفظ إعدادات المدرسة.' };
}

export async function saveScope(formData: FormData) {
  const actor = await requireFullAdmin();
  const accountId = String(formData.get('accountId') ?? '');
  const classIds = String(formData.get('classIds') ?? '').split(',').filter(Boolean);
  const studentIds = String(formData.get('studentIds') ?? '').split(',').filter(Boolean);
  const admin = createSupabaseAdmin();
  const { data: account } = await admin.from('profiles').select('id, school_id, role').eq('id', accountId).maybeSingle();
  if (!account || account.school_id !== actor.schoolId || !['admin', 'teacher'].includes(account.role)) return { error: 'الحساب المحدد غير صالح.' };
  const [{ data: validClasses }, { data: validStudents }] = await Promise.all([
    admin.from('classes').select('id').eq('school_id', actor.schoolId).in('id', classIds.length ? classIds : ['00000000-0000-0000-0000-000000000000']),
    admin.from('students').select('id').eq('school_id', actor.schoolId).in('id', studentIds.length ? studentIds : ['00000000-0000-0000-0000-000000000000'])
  ]);
  if ((validClasses?.length ?? 0) !== classIds.length || (validStudents?.length ?? 0) !== studentIds.length) return { error: 'يوجد صف أو طالب خارج مدرسة الحساب.' };

  await admin.from('account_class_links').delete().eq('account_id', accountId);
  await admin.from('account_student_links').delete().eq('account_id', accountId);
  if (classIds.length) await admin.from('account_class_links').insert(classIds.map(class_id => ({ account_id: accountId, class_id })));
  if (studentIds.length) await admin.from('account_student_links').insert(studentIds.map(student_id => ({ account_id: accountId, student_id })));
  await admin.from('audit_logs').insert({ school_id: actor.schoolId, actor_id: actor.id, action: 'update_scope', table_name: 'profiles', record_id: accountId, metadata: { classIds, studentIds } });
  revalidatePath('/admin/scope');
  return { success: 'تم حفظ نطاق الحساب.' };
}
