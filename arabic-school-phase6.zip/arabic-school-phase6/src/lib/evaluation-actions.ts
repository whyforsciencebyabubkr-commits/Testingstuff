'use server';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { createSupabaseServer } from './supabase-server';
import { createSupabaseAdmin } from './supabase-admin';
import { getCurrentProfile, requireFullAdmin } from './auth';

export async function saveEvaluation(formData: FormData) {
  const profile = await getCurrentProfile();
  if (!['teacher','admin'].includes(profile.role) || (profile.role==='admin' && profile.adminAccess!=='full')) return { error:'لا تملك صلاحية إدخال الدرجات.' };
  const parsed = z.object({studentId:z.string().uuid(),subjectId:z.string().uuid(),periodId:z.string().uuid(),score:z.coerce.number().finite().min(0).max(10000),note:z.string().max(500).optional()}).safeParse({studentId:formData.get('studentId'),subjectId:formData.get('subjectId'),periodId:formData.get('periodId'),score:formData.get('score'),note:String(formData.get('note')??'').trim()});
  if (!parsed.success) return { error:'تحقق من الدرجة والحقول المطلوبة.' };
  const supabase=await createSupabaseServer();
  const [{data:student},{data:subject},{data:period},{data:link}] = await Promise.all([
    supabase.from('students').select('id,school_id,class_id').eq('id',parsed.data.studentId).maybeSingle(),
    supabase.from('subjects').select('id,school_id').eq('id',parsed.data.subjectId).maybeSingle(),
    supabase.from('evaluation_periods').select('id,school_id,max_score,is_active').eq('id',parsed.data.periodId).maybeSingle(),
    profile.role==='teacher'?supabase.from('teacher_subjects').select('subject_id').eq('teacher_id',profile.id).eq('subject_id',parsed.data.subjectId).maybeSingle():Promise.resolve({data:{subject_id:parsed.data.subjectId}})
  ]);
  if(!student||!subject||!period||student.school_id!==profile.schoolId||subject.school_id!==profile.schoolId||period.school_id!==profile.schoolId||!period.is_active||!link||parsed.data.score>Number(period.max_score)) return {error:'الطالب أو المادة أو الفصل الدراسي غير صالح، أو الدرجة تتجاوز الحد الأعلى.'};
  if(profile.role==='teacher'){
    const {data:classScope}=await supabase.from('account_class_links').select('class_id').eq('account_id',profile.id).eq('class_id',student.class_id).maybeSingle();
    const {data:studentScope}=await supabase.from('account_student_links').select('student_id').eq('account_id',profile.id).eq('student_id',student.id).maybeSingle();
    if(!classScope&&!studentScope) return {error:'هذا الطالب خارج نطاقك.'};
  }
  const {data:existing}=await supabase.from('evaluations').select('id,teacher_id').eq('student_id',student.id).eq('subject_id',subject.id).eq('period_id',period.id).maybeSingle();
  if(existing && profile.role==='teacher' && existing.teacher_id!==profile.id) return {error:'أدخل معلم آخر درجة هذه المادة لهذا الطالب ولا يمكنك تعديلها.'};
  const values={school_id:profile.schoolId,student_id:student.id,subject_id:subject.id,period_id:period.id,teacher_id:profile.id,score:parsed.data.score,teacher_note:parsed.data.note||null};
  const result=existing ? await supabase.from('evaluations').update(values).eq('id',existing.id) : await supabase.from('evaluations').insert(values);
  if(result.error) return {error:'تعذر حفظ الدرجة. تأكد من صلاحياتك ونطاقك.'};
  await supabase.from('audit_logs').insert({school_id:profile.schoolId,actor_id:profile.id,action:existing?'update':'create',table_name:'evaluations',record_id:existing?.id??null,metadata:{student_id:student.id,subject_id:subject.id,period_id:period.id}});
  revalidatePath('/evaluations'); revalidatePath('/dashboard');
  return {success:'تم حفظ الدرجة.'};
}

export async function createEvaluationPeriod(formData:FormData){
 const actor=await requireFullAdmin(); const name=String(formData.get('name')??'').trim(); const maxScore=Number(formData.get('maxScore')); const sortOrder=Number(formData.get('sortOrder'));
 if(name.length<2||name.length>100||!Number.isFinite(maxScore)||maxScore<=0||maxScore>10000||!Number.isInteger(sortOrder)||sortOrder<1)return {error:'تحقق من اسم الفصل الدراسي والدرجة القصوى والترتيب.'};
 const admin=createSupabaseAdmin(); const {error}=await admin.from('evaluation_periods').insert({school_id:actor.schoolId,name,max_score:maxScore,sort_order:sortOrder,is_active:true});
 if(error)return {error:'تعذر إضافة الفصل الدراسي. قد يكون الاسم أو الترتيب مستخدماً.'};
 await admin.from('audit_logs').insert({school_id:actor.schoolId,actor_id:actor.id,action:'create',table_name:'evaluation_periods',metadata:{name,maxScore,sortOrder}}); revalidatePath('/admin/evaluations');revalidatePath('/evaluations');return {success:'تمت إضافة الفصل الدراسي.'};
}
export async function createThreshold(formData:FormData){
 const actor=await requireFullAdmin(); const label=String(formData.get('label')??'').trim(); const minScore=Number(formData.get('minScore')); const sortOrder=Number(formData.get('sortOrder'));
 if(label.length<2||label.length>80||!Number.isFinite(minScore)||minScore<0||minScore>100||!Number.isInteger(sortOrder)||sortOrder<1)return {error:'أدخل تصنيفاً صالحاً ونسبة من 0 إلى 100 وترتيباً صحيحاً.'};
 const admin=createSupabaseAdmin();const {error}=await admin.from('evaluation_thresholds').insert({school_id:actor.schoolId,label,min_score:minScore,sort_order:sortOrder});if(error)return {error:'تعذر حفظ التصنيف. تحقق من عدم تكرار الاسم أو الترتيب.'};
 await admin.from('audit_logs').insert({school_id:actor.schoolId,actor_id:actor.id,action:'create',table_name:'evaluation_thresholds',metadata:{label,minScore,sortOrder}});revalidatePath('/admin/evaluations');revalidatePath('/evaluations');return {success:'تمت إضافة التصنيف.'};
}
export async function publishResults(formData:FormData){
 const actor=await requireFullAdmin();const classId=String(formData.get('classId')??'');const periodId=String(formData.get('periodId')??'');if(!z.string().uuid().safeParse(classId).success||!z.string().uuid().safeParse(periodId).success)return {error:'اختر الصف والفصل الدراسي.'};
 const supabase=await createSupabaseServer();const {error}=await supabase.rpc('publish_evaluation_results',{p_class_id:classId,p_period_id:periodId});if(error)return {error:'تعذر نشر النتائج. تحقق من الصف والفصل الدراسي.'};
 revalidatePath('/evaluations');revalidatePath('/ranking');revalidatePath('/dashboard');return {success:'تم نشر نتائج الصف لهذا الفصل الدراسي.'};
}
