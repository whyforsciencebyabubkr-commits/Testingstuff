import { redirect } from 'next/navigation';
import { createSupabaseServer } from './supabase-server';
import type { CurrentProfile } from '@/types/auth';

export async function getCurrentProfile(): Promise<CurrentProfile> {
  const supabase = await createSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data, error } = await supabase
    .from('profiles')
    .select('id, school_id, role, username, full_name, is_active, must_change_password, admin_access')
    .eq('id', user.id)
    .maybeSingle();
  if (error || !data || !data.is_active) redirect('/login');
  if (data.must_change_password) redirect('/change-password');
  return {
    id: data.id,
    schoolId: data.school_id,
    role: data.role,
    username: data.username,
    fullName: data.full_name,
    isActive: data.is_active,
    mustChangePassword: data.must_change_password,
    adminAccess: data.admin_access,
  };
}

export async function requireFullAdmin() {
  const profile = await getCurrentProfile();
  if (profile.role !== 'admin' || profile.adminAccess !== 'full') redirect('/dashboard');
  return profile;
}
