# Phase 3 — منصة الواجبات

## Implemented
- Arabic RTL homework list and details pages.
- New homework form with title, subject, description, deadline, class targets, individual-student targets, and up to five image/PDF attachments.
- Teacher subject assignment check and scope enforcement in PostgreSQL triggers/RLS.
- Private Supabase Storage bucket with recipient-only read policies and signed links that expire after five minutes.
- Student list is restricted by RLS to homework addressed to the student, with nearest deadlines first and due-state labels.
- Admin/teacher list filters for class, subject, and active/archived status.
- Edit details, archive/reactivate, delete, and duplicate to a selected class.
- Audit events for create/edit/archive/delete/duplicate.
- Migration `0002_homework.sql` and updated navigation.

## Setup / test
1. Configure `.env.local` from `.env.example` and start local Supabase.
2. Run `npm install`, then `npm run supabase:reset` to apply both migrations and seed demo data.
3. Run `npm run dev`, sign in as a teacher/admin, and open `/homework`.
4. Create a homework with a class target, a subject the teacher is assigned to, and an optional PDF/image attachment.
5. Sign in as a student in the target class and verify the homework is visible; sign in as a student in another class and verify it is absent.
6. Attempt direct Supabase queries with the other student's session and attempt to open a non-recipient attachment path; both should be denied by RLS/storage policies.
7. As a teacher, attempt to edit another teacher's homework and choose a subject not assigned to them; server/database must reject both.
8. Try selecting an out-of-scope class/student via a forged request; target validation must reject it.
9. Check 360px mobile width and desktop layout.

## Verification status
The source files and database migration were authored, but `npm build`, typecheck, and live database/RLS tests have not yet been run in this environment. Do not treat deployment as production-ready until those commands pass against a fresh Supabase reset and the manual authorization tests above pass.

## Assumptions / known limitations
- Allowed attachments are JPEG, PNG, WebP, and PDF; 10 MB each, maximum five per homework.
- Deadlines are stored as UTC timestamps and displayed in Asia/Baghdad in this phase; school-specific timezone display is a follow-up hardening item.
- Editing the core fields is supported; audience target changes are not exposed in the edit form yet. Create a new homework or duplicate to another class to change the target audience.
- A teacher can only use subjects explicitly linked in `teacher_subjects`.
