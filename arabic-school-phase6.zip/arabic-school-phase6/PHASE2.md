# Phase 2 — Login, RTL shell, and admin panel

## Included
- Real Supabase password login using school usernames mapped to internal auth emails.
- Server-side role verification after authentication.
- Forced first-login password change.
- Protected server-rendered dashboard and admin routes.
- Arabic RTL responsive layout for desktop and 360px+ mobile.
- Desktop right-side navigation and mobile bottom navigation.
- Top bar with school name, user, role, menu, logout, and admin panel entry.
- Full-access admin account management: create, activate/deactivate, reset temporary password.
- Scope linking for admins/teachers to classes and individual students.
- Scope summary counts per account.
- School settings: name, timezone, primary color, and show/hide “من N”.
- Server-side audit log writes for Phase 2 administration actions.

## Run
1. Copy `.env.example` to `.env.local` and fill Supabase values.
2. Start local Supabase: `npm run supabase:start`.
3. Reset/seed: `npm run supabase:reset`.
4. Install dependencies: `npm install`.
5. Start: `npm run dev`.
6. Open `/login`.

## Demo accounts
See `supabase/seed.sql` for demo usernames and passwords. The login demo panel is shown only when `NEXT_PUBLIC_SHOW_DEMO_LOGINS=true`.

## Phase 2 test checklist
- Login with a teacher while selecting Student: server rejects the role mismatch.
- Login with `teacher_a`: dashboard identifies the user as a teacher.
- Login with a seeded account: first login forces password change.
- Login as restricted admin: `/admin` redirects away; it cannot create accounts or change links.
- Login as main admin: can open `/admin`, `/admin/users`, `/admin/scope`, and `/admin/settings`.
- Create a student and confirm a temporary password is required to be changed on first login.
- Change school name/color and confirm the top bar/dashboard uses the new values.
- Resize browser to 360px width: bottom navigation remains usable without horizontal overflow.
- Attempt to access admin pages while logged out: server redirects to `/login`.

## Verification note
The source was reviewed statically in this environment, but dependency installation/build could not be completed because the package installation command timed out and `node_modules` is not present. Do not treat the phase as runtime-verified until `npm install`, `npm run build`, and the Supabase reset/test commands pass in a network-enabled development environment.
